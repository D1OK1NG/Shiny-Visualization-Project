
function random_probability_vector(n, numZero) {

	var v = [], dp = 1;

	var propZero = numZero/n,
	    zeroCount = 0,
	    isZero;

	d3.range(n).forEach(function() {
		isZero = Math.random() < propZero && zeroCount < numZero;
		if (isZero)
			zeroCount++;
		v.push(isZero ? 0 : Math.random());
	});

	var p, s = d3.sum(v);

	v.forEach(function(value, i) {
		p = value / s;
		v[i] = d3.round(p, dp);
	});

	// Adjust in case rounding means the sum is not exactly 1
	s = d3.sum(v);


	var adjustIndex = 0;

	while (Math.abs(s - 1) > 1e-8) {
		v[adjustIndex] = Math.max(0, d3.round(v[adjustIndex] - (s - 1), dp));
		s = d3.sum(v);
		adjustIndex++;
	}

	return v;

}




function repeat(value, times) {

	// Should we clone the value?
	var cloneValue = _.isObject(value),
		deepClone = cloneValue && !_.isArray(value);

	if (_.isNumber(times) && times >= 0) 
		return _.range(times).map(function(x) {
			return (cloneValue ? _.clone(value, deepClone) : value);
		});

	return undefined;

}




function item_list_text(items) {

	if (!(_.isArray(items) && items.length))
		return undefined;

	if (items.length === 1)
		return items[0];

	if (items.length === 2)
		return items.join(" and ");

	return _.initial(items).join(", ") + " and " + _.last(items);

}




function random_transition_matrix(n) {

	var m = d3.range(n).map(function() {
		return random_probability_vector(n);
	});
	return m;

}





function zero_matrix(n) {

	var m = d3.range(n).map(function() {
		return d3.range(n).map(function() { return 0; });
	});
	return m;

}




function is_fraction(x) {

	x = ("" + x).trim();

	if (x.length < 3 || x.indexOf("/") === -1)
		return false;

	var parts = x.split("/"),
	    numerator = +parts[0],
	    denominator = +parts[1];

	return (_.isNumber(numerator)
		&& _.isNumber(denominator)
		&& parts[0].length > 0
		&& parts[1].length > 0
		&& !_.isNaN(numerator)
		&& !_.isNaN(denominator)
		&& denominator !== 0);

}



function to_number(x) {

	if (is_fraction(x)) {

		var parts = x.split("/"),
		    numerator = +parts[0],
		    denominator = +parts[1];

		return numerator/denominator;

	}

	x = +x;

	return _.isNaN(x) ? undefined : x;

}




function get_element_size(el) {

	return {
		width: el.clientWidth,
		height: el.clientHeight
	};

}




function make_vector(x, y) {

	var v = {x: x, y: y};

	// All methods return a new vector object.

	v.rot = function(theta) {
		var x = v.x * Math.cos(theta) - v.y * Math.sin(theta);
		var y = v.x * Math.sin(theta) + v.y * Math.cos(theta);
		return make_vector(x, y);
	};

	v.unit = function() {
		var l = v.len();
		return make_vector(v.x / l, v.y / l);
	};

	v.len = function() {
		return Math.sqrt( v.x * v.x + v.y * v.y );
	};

	v.sub = function(b) {
		return make_vector(v.x - b.x, v.y - b.y);
	};

	v.add = function(b) {
		return make_vector(v.x + b.x, v.y + b.y);
	};

	v.scale = function(s) {
		return make_vector(v.x * s, v.y * s);
	};

	v.rotDegrees = function(theta) {
		return v.rot(theta * Math.PI / 180);
	};

	v.array = function() {
		return [v.x, v.y];
	};

	return v;

}
