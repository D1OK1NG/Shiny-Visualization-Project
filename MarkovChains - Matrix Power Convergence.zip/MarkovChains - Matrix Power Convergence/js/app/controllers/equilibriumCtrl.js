markovApp.controller("equilibriumCtrl", ['$scope', function($scope) {


	function get_equilibrium_distribution(transitionMatrix, dp) {

		var matrix = Matrix.create(transitionMatrix),
		    identity = Matrix.I(transitionMatrix.length),
		    matrixSubIdentity = matrix.subtract(identity);

		var i, newM = [],
		    size = matrix.rows();

		for (i = 1; i < size; i++)
			newM.push(matrixSubIdentity.col(i).elements);

		var ones = d3.range(size).map(function(x) { return 1; }),
		    onesVector = Vector.create(ones);

		newM.push(onesVector.elements);

		var invMatrix = Matrix.create(newM).inverse();

		if (!invMatrix)
			return null;

		var rightHandSide = d3.range(size).map(function(x) { return 0; });
		rightHandSide[rightHandSide.length - 1] = 1;

		var rhsVector = Vector.create(rightHandSide);

		var equilibrium = invMatrix.multiply(rhsVector).elements;

		return equilibrium.map(function(prob) {
			return d3.round(prob, _.isUndefined(dp) ? 4 : dp);
		});

	}


	// Watch for changes in the active transition matrix.
	// Update the calculated equilibrium distribution in response.
	$scope.$watch(function() {
		return JSON.stringify($scope.appState.activeTransitionMatrix);
	},
	function() {
		if ($scope.appState.activeTransitionMatrix)
			$scope.features.equilibrium.equilibrium =
				get_equilibrium_distribution($scope.appState.activeTransitionMatrix);
	});



	/* Watch for changes in the results array, and when a change is detected
	** we update the counts and proportions for each state.
	*/

	$scope.$watch(function() {

		return JSON.stringify($scope.features.equilibrium.DATA);

	}, function() {

		// Get state names, e.g. ["A", "B", "C"]
		var stateNames = _.pluck($scope.appState.activeStates, "label");

		// Calculate the total times each state has been visited
		var totals = $scope.appState.activeStates.map(function(state) {

			var filteredResults = _.filter($scope.features.equilibrium.DATA, function(s) {
				return s === state.label;
			});

			return filteredResults.length;

		});

		// Calculate proportions for each state
		var proportions = (_.max(totals) > 0
			? totals.map(function(x) { return (x / d3.sum(totals)).toFixed(4); })
			: totals.map(function(x) { return "-"; }));

		// Assign the counts and proportions results to the controller scope
		// (will be used in directives and also view for this controller).
		$scope.counts = _.object(stateNames, totals);
		$scope.proportions = _.object(stateNames, proportions);

	});

	
    function matMul(A, B) {
        var rows = A.length;
        var cols = B[0].length;
        var inner = B.length;
        var C = new Array(rows);
        var i, j, k, sum;

        for (i = 0; i < rows; i++) {
            C[i] = new Array(cols);
            for (j = 0; j < cols; j++) {
                sum = 0;
                for (k = 0; k < inner; k++) {
                    sum += A[i][k] * B[k][j];
                }
                C[i][j] = sum;
            }
        }
        return C;
    }

    function matsClose(A, B, tol) {
        if (tol === undefined) tol = 1e-4;
        if (!A || !B) return false;
        if (A.length !== B.length || A[0].length !== B[0].length) return false;

        var i, j;
        for (i = 0; i < A.length; i++) {
            for (j = 0; j < A[0].length; j++) {
                if (Math.abs(A[i][j] - B[i][j]) >= tol) {
                    return false;
                }
            }
        }
        return true;
    }

    function formatMatrix(mat) {
        return mat.map(function(row) {
            return row.map(function(v) {
                return v.toFixed(4);
            });
        });
    }
	    // ---------------- Matrix power convergence (P^n) state ----------------
    $scope.power = {
        steps: [],
        convergedPower: null
    };

	    // 主入口：计算 P, P^2, ..., P^n 直到收敛或达到上限
    $scope.runMatrixPower = function() {

        var P = $scope.appState.activeTransitionMatrix;
        if (!P || !P.length) {
            // 没有有效转移矩阵，清空结果
            $scope.power.steps = [];
            $scope.power.convergedPower = null;
            return;
        }

        var n = P.length;

        // 深拷贝当前 P 作为 P^1
        var current = P.map(function(row) {
            return row.slice();
        });

        var prev = null;
        var steps = [];
        var maxSteps = 50;
        var tol = 1e-4;

        for (var k = 1; k <= maxSteps; k++) {

            // 记录当前 P^k
            steps.push({
                power: k,
                matrix: formatMatrix(current)
            });

            // 从第二步开始判断是否收敛：P^k ≈ P^(k-1)
            if (prev && matsClose(prev, current, tol)) {
                $scope.power.steps = steps;
                $scope.power.convergedPower = k;
                return;
            }

            // 计算下一步 P^(k+1) = P^k * P
            prev = current;
            current = matMul(current, P);
        }

        // 如果 50 步内没有收敛，也把结果展示出来
        $scope.power.steps = steps;
        $scope.power.convergedPower = null;
    };

}]);
