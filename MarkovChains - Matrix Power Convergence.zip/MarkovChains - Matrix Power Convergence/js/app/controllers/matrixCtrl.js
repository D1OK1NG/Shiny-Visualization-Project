markovApp.controller("matrixCtrl", ['$scope', '$rootScope', '$compile', 'settings',
	function($scope, $rootScope, $compile, settings) {

	// Object to store whether or not each row is valid.
	// The property names will be the state label for each row, values are true/false.
	// e.g. {A: true, B: true, C: false}.
	$scope.validRow = {};

	// Local variable to store the status of the last edit action.
	var lastEditCancelled = false;


	$scope.toggleEditMode = function() {

		$scope.appState.editMode = !$scope.appState.editMode;

		// If and edit was just completed, set lastEditCancelled to false.
		if (!$scope.appState.editMode)
			lastEditCancelled = false;

	};


	$scope.$watch('appState.editMode', function(newVal, oldVal) {

		// initial call
		if (newVal === oldVal && !newVal) {
			validateMatrix();
			return;
		}

		if ($scope.appState.editMode) {

			$scope.appState.paused = true;
			$scope.features[$scope.appState.activeFeature].running = false;

		} else {

			// Validate new matrix (unless the last edit was cancelled)
			if (!lastEditCancelled)
				validateMatrix();

		}

	});


	// Possible states (local). The set of states will be derived from this array.
	var possibleStates = [];
	d3.range(settings.matrix.nodesMax).map(function(i) {
		possibleStates.push(String.fromCharCode(65 + i));
	});


	// Local function for setting the states
	function setStates() {

		var states = possibleStates.slice(0, $scope.appState.numberOfNodes);

		$scope.appState.states = states.map(function(s, i) {
			return {label: s, index: i};
		});

	}


	function updateTransitionMatrix() {

		// Update the numeric representations of the values in the displayMatrix.
		var matrix = angular.copy($scope.appState.displayMatrix);

		matrix.forEach(function(row, i) {
			row.forEach(function(col, j) {
				matrix[i][j] = ("" + col).length ? to_number(matrix[i][j]) : null;
			});
		});

		$scope.appState.transitionMatrix = matrix;

	}


	// Local function for setting the transitionMatrix. Note that the matrix used
	// by the markov diagram is activeTransitionMatrix. This is not set until all
	// checks have been done on transitionMatrix and all values are valid.

	function setMatrix(matrix) {

		// Use null to set all values in the matrix to empty string. This is used to
		// empty out all of the input elements to leave them blank, for a better
		// experience for the user when filling out a whole matrix.
		if (matrix === null) {
			var n = $scope.appState.numberOfNodes;
			matrix = repeat(repeat("", n), n);
			matrix.forEach(function(row, i) {
				row.forEach(function(col, j) {
					matrix[i][j] = "";
				});
			});
		} else {
			// convert values to strings
			matrix.forEach(function(row, i) {
				row.forEach(function(val, j) {
					matrix[i][j] = "" + val;
				});
			});
		}

		$scope.appState.displayMatrix = matrix;
		updateTransitionMatrix();

	}


	$scope.newMatrix = function(m) {

		/* Supply no argument to generated random matrix.
		** Supply null to empty the matrix.
		** Otherwise supply a custom matrix to set.
		*/

		// First check the number of nodes is valid.
		var validNodes = ($scope.appState.numberOfNodes >= settings.matrix.nodesMin
			&& $scope.appState.numberOfNodes <= settings.matrix.nodesMax);

		// Exit function is invalid number of nodes is set
		if (!validNodes)
			return;

		// null is a valid value (empty the matrix), so use undefined to get a random matrix
		if (_.isUndefined(m))
			m = random_transition_matrix($scope.appState.numberOfNodes);

		setMatrix(m);
		setStates();

		$scope.validRow = {};
		$scope.allRowsValid = true;

	};


	$scope.cancelChanges = function() {

		/* Call this method to cancel any changes made in edit mode
		** before the Apply button has been clicked. Will then revert
		** to activeTransitionMatrix.
		*/

		// The last edit was cancelled, update local variable to reflect this
		lastEditCancelled = true;

		// Set the matrix to the active transition matrix. This will update
		// the display matrix and it's numeric representation as well.
		setMatrix(angular.copy($scope.appState.activeTransitionMatrix));

		$scope.appState.states = angular.copy($scope.appState.activeStates);
		$scope.appState.numberOfNodes = $scope.appState.activeTransitionMatrix.length;

		$scope.validRow = {};
		$scope.allRowsValid = true;
		$scope.appState.editMode = false;

	};


	// Controller behaviour that empties the transition matrix. 
	$scope.emptyMatrix = function() {
		$scope.newMatrix(null);
	};


	// Controller behaviour used to validate the matrix when the Apply button
	// is clicked. We only need to validate the row sums here, as we use a custom
	// directive to validate each of the individual cells (input elements).

	function validateMatrix() {

		var m = $scope.appState.transitionMatrix,
		    validRowSum,
		    valid = true;

		// Check row sums of transition matrix
		m.forEach(function(row, i) {
			validRowSum = (Math.abs(d3.sum(row) - 1) < 1e-8)
			$scope.validRow[$scope.appState.states[i].label] = validRowSum;
			valid = valid && validRowSum;
		});

		$scope.allRowsValid = valid;

		// If all rows valid, update the activeTransitionMatrix property
		// and the activeStates property. Broadcast a matrixApply event
		// from the root scope.
		if (valid) {
			applyMatrix();
		} else {
			// If row sums are not valid, switch back into edit mode
			$scope.appState.editMode = true;
		}

	};

	function applyMatrix() {

		$scope.appState.activeTransitionMatrix = angular.copy($scope.appState.transitionMatrix);
		$scope.appState.activeStates = angular.copy($scope.appState.states);
		$rootScope.$broadcast('matrixApply');

	}


	// Monitor changes in the activeTransitionMatrix. When it changes,
	// update the hash of the URL. This means that if this application
	// is used on a web server, then a link with a specific transition
	// matrix can be generated.

	/*$scope.$watch(function() {
		return JSON.stringify($scope.appState.activeTransitionMatrix);
	}, function() {
		var hash = JSON.stringify($scope.appState.activeTransitionMatrix);
		$location.hash(hash);
	});*/


	$scope.getMatrixCode = function() {

		var title = "Copy Matrix Code";
		
		var content = "<p>Copy the following code to reuse this matrix later. To reuse, click "
		    	+ "the matrix <b>Paste</b> button and insert the code.</p>"
		    	+ '<textarea cols="50" rows="4">' + JSON.stringify($scope.appState.displayMatrix) + '</textarea>';

		$scope.appState.message.show(title, content);

	};



	$scope.pastedMatrix = null;

	$scope.pasteMatrixCode = function() {

		$scope.pastedMatrix = null;

		var title = "Paste Matrix Code";
		var content = "<p>Paste matrix code below, then click Apply.</p>";

		$scope.appState.message.show(title, content);

		// Strictly, we shouldn't be changing the document structure
		// inside a controller. Perhaps messages would be better as a
		// directive. Currently we are forced to add extra elements on
		// here and use the $compile service to make angular features
		// on those elements work, e.g. ng-model, ng-click.

		var el = d3.select("#message .additionalContent");

		el.append("textarea")
			.attr("rows", 4)
			.attr("cols", 50)
			.attr("ng-model", "pastedMatrix");

		el.append("button")
			.attr("class", "btn btn-sm btn-default")
			.attr("ng-click", "verifyMatrixCode()")
			.text("Apply");

		$compile(angular.element(el.node()))($scope);

	};



	/* This function verifies whether or not a matrix code that has
	** been pasted in using the Paste feature is valid.
	*/
	$scope.verifyMatrixCode = function() {

		var m, valid = false;

		if ($scope.pastedMatrix) {

			// Try parse it as JSON
			try {
				m = JSON.parse($scope.pastedMatrix);
				valid = true;
			} catch(e) {}

			// Check it is an array and has length at least 2
			valid = valid && _.isArray(m)
				&& (m.length >= 2);

			// Check that all sub-arrays are the same length
			// as the overall array (square matrix check)
			if (valid) {
				var n = m.length;
				for (var i = 0; i < n; i++) {
					if (m[i].length !== n) {
						valid = false;
						break;
					}
				}
			}

			if (valid) {

				var entries = _.flatten(m),
				    values = _.map(entries, to_number);

				// Check all values converted to numbers are defined
				valid = !_.any(_.map(values, _.isUndefined));

				// Check all values are valid probabilities
				valid = valid && _.all(_.map(values, function(prob) {
					return (prob >= 0 && prob <= 1);
				}));

				// Check all rows sum to 1
				valid = valid && _.all(_.map(m, function(row) {

					var probs = _.map(row, to_number);
					return Math.abs(1 - d3.sum(probs)) < 1e-8;

				}));

			}

		}

		if (valid) {

			$scope.appState.message.error = null;
			$scope.appState.message.close();
			$scope.appState.numberOfNodes = m.length;
			$scope.newMatrix(m);
			applyMatrix();

		} else {

			$scope.appState.message.error = "Matrix code is invalid";

		}


	};



	// Behaviour for editing a transition matrix cell (input element).
	$scope.editCell = function(row, col) {

		/* Supply row and col to highlight the state cells along the top and
		** left of the transition matrix table. (called using the ngFocus directive)
		** Supply this method with no arguments to remove cell highlighting
		** (called using the ngBlur directive).
		*/

		if (_.isUndefined(row) && _.isUndefined(col)) {

			var v = $scope.appState.displayMatrix[$scope.rowIndex][$scope.colIndex];

			// Only process is value is defined
			if (!_.isUndefined(v)) {
				
				// Convert to number
				var vNum = to_number(v);

				// If the converted number is valid
				if (v !== "" && _.isNumber(vNum) && !_.isNaN(vNum)) {

					// Save the numeric value in the transition matrix
					$scope.appState.transitionMatrix[$scope.rowIndex][$scope.colIndex] = vNum;

					// Save the value to the display matrix as a number only if it is not
					// a fraction text string e.g. 1/3.
					if (!is_fraction(v))
						$scope.appState.displayMatrix[$scope.rowIndex][$scope.colIndex] = "" + vNum;

				}
			}

			// Set these values to null to remove the highlight classes from row/col state cells.
			$scope.rowIndex = null;
			$scope.colIndex = null;

		} else {	

			// Set the values on the scope, so that they can be used in an ngClass
			// directive within the view to highlight the state cells corresponding
			// to the cell currently being edited.
			$scope.rowIndex = row;
			$scope.colIndex = col;

		}

	};


	// This function will fill in any empty cells in the matrix with zeros. This
	// is useful for filling in sparse transition matrices with a small proportion
	// of non-zero probabilities.
	$scope.emptyToZero = function() {

		var m = angular.copy($scope.appState.transitionMatrix)

		$scope.appState.displayMatrix.forEach(function(row, i) {
			row.forEach(function(prob, j) {
				if (_.isUndefined(prob) || !(prob + "").length) {
					$scope.appState.displayMatrix[i][j] = "0";
					$scope.appState.transitionMatrix[i][j] = 0;
				}
			});
		});

	};


	// When the number of nodes changes, set new random matrix automatically.
	$scope.$watch('appState.numberOfNodes', function(newVal, oldVal) {
		if (newVal !== oldVal && $scope.appState.editMode) {

			var m = (_.all(_.map(_.flatten($scope.appState.displayMatrix), _.isEmpty))
				? null
				:undefined);

			$scope.newMatrix(m);

		}
	});


	// Generate initial transition matrix
	/*var initialMatrix = ($location.hash().length
		? JSON.parse($location.hash())
		: undefined);*/


	// If an initial matrix has been specified in settings, update numberOfNodes
	// to match this matrix.
	if (!_.isUndefined($scope.settings.matrix.initial))
		$scope.appState.numberOfNodes = $scope.settings.matrix.initial.length;

	// Generate initial matrix
	$scope.newMatrix($scope.settings.matrix.initial);

}]);
