
/****************************  NOTES  ******************************

It is useful to have a separate display matrix, and a transition matrix
in the background which stores the numeric values. This allows users
to enter fractions into the cells without the values instantly getting
converted into long floating point values due to two-way AngularJS
bindings. The two matrices are kept in sync with each other. When a valid
transition matrix is applied (by clicking the Apply button), the numeric
transition matrix is made the new active transition matrix, triggering
a new state diagram to be created by D3.js.

********************************************************************/

markovApp.controller("mainCtrl", ['$scope', '$sce', 'settings',
	function($scope, $sce, settings) {

	// Settings (copy into scope so we can use in the view)
	$scope.settings = settings;

	// Detects IE up to 11 (current version as of writing)
	$scope.isIE = "ActiveXObject" in window;

	// Store application-level information here. Data that will be accessible by
	// all children controllers.

	$scope.appState = {

		numberOfNodes: settings.matrix.nodesDefault,

		states: undefined,
		activeStates: undefined,
		startProbabilities: null,
		startProbabilityLabels: null,
		useStartProbabilities: false,

		editMode: false,
		paused: true,

		selectedMatrixCell: null,
		selectedTransition: [-1, -1],
		highlightedState: 0,

		displayMatrix: undefined,
		transitionMatrix: undefined,
		activeTransitionMatrix: undefined,

		// Feature that is active by default when the app is first loaded.
		activeFeature: "equilibrium"

	};

	$scope.appState.message = {

		visible: false,
		title: 'Message title',
		content: $sce.trustAsHtml('<p>Message content</p>'),
		error: null,

		close: function() {
			this.visible = false;
		},

		show: function(title, content) {

			this.title = title;
			this.content = $sce.trustAsHtml(content);
			d3.select("#message .additionalContent").html("");
			this.error = null;
			this.visible = true;

		}

	};


	/* Entrapments will be a matrix of the same dimensions as the transition
	** matrix. It encodes whether or not it is possible to ever reach a state
	** when we are in some other state. A value of 1 means it is possible;
	** a value of 0 means that it is not possible. E.g. if the (1,2) entry
	** is 1, this means it is possible to reach state B from state A. This
	** is used in the hitting times simulation. If we detect we are trapped
	** from reaching the destination state, we skip to the next 'iteration'.
	*/
	$scope.appState.entrapments = null;


	// Feature specific functionality will be stored in this features object
	$scope.features = {};


	// Properties & methods relevant to all/multiple features
	$scope.features.all = {

		reset: function() {
			$scope.$broadcast("reset");
		},

		getStateLabel: function(i) {
			return $scope.appState.activeStates[i].label;
		},

		getSpeed: function() {
			return $scope.features[$scope.appState.activeFeature].speed;
		},

		getAnimationDuration: function() {
			return 2000 / this.getSpeed();
		},

		clearDATA: function() {

			["equilibrium", "hittingTimes"].forEach(function(f) {

				$scope.features[f].DATA = [];
				$scope.features[f].running = false;
				$scope.features[f].finished = true;

			});

		}

	};


	// Properties & methods relevant to the equilibrium feature
	$scope.features.equilibrium = {

		initialState: 0,
		currentState: 0,
		equilibrium: null,
		showEquilibrium: false,
		running: false,
		finished: true,
		DATA: [],

		speed: settings.features.equilibrium.speedDefault,
		animation: true,

		// This value will be remultiplied by stepsResolution to get the actual value
		__numSteps: settings.features.equilibrium.stepsDefault / settings.features.equilibrium.stepsResolution,

		setInitialState: function(i) {
			this.initialState = i;
			this.currentState = i;
		},

		startPause: function() {

			if (this.finished) {
				// A new simulation is just starting

				this.DATA = [];
				this.finished = false;
				$scope.appState.startedMainSimulation = true;

				if ($scope.appState.useStartProbabilities) {
					var r = Math.random();
					var i = -1, s = 0;
					while (s < r) {
						i += 1;
						s += $scope.appState.startProbabilities[i];
					}
					this.initialState = i;
				}

				// Make sure we record this initial state!
				var s = $scope.appState.activeStates[this.initialState];
				$scope.features.equilibrium.recordState(s);

			}

			this.running = !this.running;
			$scope.appState.paused = !this.running;

		},

		recordState: function(state) {
			this.currentState = state.index;
			this.DATA.push(state.label);
		}

	};


	// Properties & methods relevant to the hitting times feature
	$scope.features.hittingTimes = {

		fromState: 0,
		endStates: [1],
		currentState: 0,
		//isEndState: [false, true, false],
		// Are the simulations currently running (they can be paused)
		running: false,
		// Have we completed the set of simulations?
		finished: true,
		DATA: [],

		speed: settings.features.hittingTimes.speedDefault,
		animation: true,
		volume: 0,

		// This value will be remultiplied by simsResolution to get the actual value
		__numSims: settings.features.hittingTimes.simsDefault / settings.features.hittingTimes.simsResolution,

		setFromState: function(i) {
			this.fromState = i;
			this.currentState = i;
		},

		getEndStateNames: function() {

			if (!$scope.appState.activeStates)
				return '';

			var s = $scope.features.hittingTimes.endStates.map(function(i) {
				return $scope.appState.activeStates[i].label;
			});

			return '[ ' + s.join(', ') + ' ]';

		},

		startPause: function() {

			if (this.finished) {
				this.DATA = [];
				this.times = [];
				this.finiteTimes = [];
				this.currentHitTime = $sce.trustAsHtml("-");
				this.previousHitTime = $sce.trustAsHtml("-");
				this.fromStateLabel = $scope.features.all.getStateLabel(this.fromState);
				this.toStateLabel = this.getEndStateNames();
				this.finished = false;
			}

			this.running = !this.running;
			$scope.appState.paused = !this.running;

		},

		recordState: function(state) {
			this.DATA.push(state.label);
		}

	};

	$scope.features.entrapmentStates = {};



	// Triggered when a new state is determined in the state-diagram directive.
	$scope.$on('stateChange', function(event, stateChange) {
		if (!$scope.appState.paused)
			$scope.appState.selectedMatrixCell = stateChange.from.label + "-" + stateChange.to.label;
	});



	// Controller behaviour for switching between features.
	$scope.switchFeature = function(featureName) {

		// Pause any simulation currently active
		$scope.appState.paused = true;
		$scope.features[$scope.appState.activeFeature].running = false;

		// Update the activeFeature
		$scope.appState.activeFeature = featureName;

	};

}]);
