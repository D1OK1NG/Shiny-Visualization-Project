markovApp.controller("diagramCtrl", ['$scope', 'settings', '$timeout', '$compile',
	function($scope, settings, $timeout, $compile) {


	// Local function for updating the state that is currently highlighted.
	function changeHighlightedState(s) {
		$scope.$broadcast("changeHighlightedState", s);
	};



	// Watch for changes in the initialState setting of the equilibrium
	// feature. If this feature is currently active, change the state
	// that is currently highlighted.

	$scope.$watch('features.equilibrium.initialState', function(s) {
		if (!_.isUndefined(s) && $scope.appState.activeFeature === "equilibrium") {
			changeHighlightedState(s);
		}
	});



	// Watch for changes in the fromState setting of the hittingTimes
	// feature. If this feature is currently active, change the state
	// that is currently highlighted.

	$scope.$watch('features.hittingTimes.fromState', function(s) {
		if (!_.isUndefined(s) && $scope.appState.activeFeature === "hittingTimes") {
			changeHighlightedState(s);
		}
	});



	// Watch for changes in the range inputs controlling the simulation
	// size for each feature. Due to a problem with range inputs taking
	// large values with AngularJS, the range inputs use steps of 1,
	// with each step representing a larger increase in the relevant
	// setting. Respond to changes by calculating the actual values
	// represented by the range inputs.

	$scope.$watch('features.equilibrium.__numSteps', function(n) {
		$scope.features.equilibrium.numSteps = n * $scope.settings.features.equilibrium.stepsResolution;
	});
	$scope.$watch('features.hittingTimes.__numSims', function(n) {
		$scope.features.hittingTimes.numSims = n * $scope.settings.features.hittingTimes.simsResolution;
	});



	// Watch for changes in the active feature. When detected, remove
	// and selected transition in the diagram and change the highlighted
	// state to match the relevant features currentState property.

	$scope.$watch('appState.activeFeature', function(feature) {

		var s = (feature === "equilibrium"
			? $scope.features.equilibrium.currentState
			: $scope.features.hittingTimes.currentState);

		$scope.appState.selectedTransition = [-1, -1];
		$scope.appState.selectedMatrixCell = null;
		changeHighlightedState(s);

	});



	// Watch for the finishedSimulation event, which fires when a simulation
	// (in any feature) finishes. Update feature-specific properties when
	// this happens.

	$scope.$on("finishedSimulation", function() {

		$timeout(function() {

			var af = $scope.appState.activeFeature;

			$scope.features[af].running = false;
			$scope.features[af].finished = true;

			$scope.appState.paused = true;

		}, 0);

	});



	// Local function to reset everything
	function reset() {

		// Simulation has not started
		$scope.appState.startedMainSimulation = false;

		// Simulation is not playing
		$scope.appState.paused = true;

		// Reset selected matrix cell
		$scope.appState.selectedMatrixCell = null;

		// Reset highlighted transition arrow in state diagram
		$scope.appState.selectedTransition = [-1, -1];

		$scope.appState.startProbabilities = null;
		$scope.appState.useStartProbabilities = false;

		// Empty state data arrays
		$scope.features.all.clearDATA();

		// Empty hitting times results array
		$scope.features.hittingTimes.times = [];
		$scope.features.hittingTimes.running = false;
		$scope.features.hittingTimes.finiteTimes = [];
		$scope.features.hittingTimes.fromStateLabel = undefined;
		$scope.features.hittingTimes.toStateLabel = undefined;

		// Clear the current hit time if any is set
		$scope.features.hittingTimes.currentHitTime = undefined;

	}

	// Call reset function when the reset event fires.
	$scope.$on("reset", reset);



	// Listen for the matrixApply event. This is broadcast by the matrixCtrl
	// validateMatrix behaviour, which is called when the Apply button is clicked.
	$scope.$on('matrixApply', function(event) {

		reset();

		// Time of diagram generation. Used to redraw diagram when Apply is
		// clicked more than once, when no other watched variables change.
		$scope.appState.generatedAt = (new Date()).getTime();

		var nStates = $scope.appState.activeStates.length;

		// Set initial state to first state in the situation where the new markov chain has
		// less states than the previous and so now the current initial state is invalid.
		if ($scope.features.equilibrium.initialState >= nStates)
			$scope.features.equilibrium.setInitialState(0);

		if ($scope.features.hittingTimes.fromState >= nStates)
			$scope.features.hittingTimes.setFromState(0);
		
		if ($scope.features.hittingTimes.toState >= nStates)
			$scope.features.hittingTimes.setToState(nStates - 1);
		
		var ies = [];

		$scope.appState.activeStates.forEach(function(s, i) {
			ies.push($scope.features.hittingTimes.endStates.indexOf(i) > -1);
		});

		$scope.features.hittingTimes.isEndState = ies;

		var es = [];

		ies.forEach(function(isEnd, i) {
			if (isEnd) es.push(i);
		});

		$scope.features.hittingTimes.endStates = es;


	});



	// Listen for stateChange events. These are broadcast when
	// the next state has been determined in the state diagram simulation.
	// Record the destination state in the data array for the currently
	// active feature.

	$scope.$on('stateChange', function(event, stateChange) {
		// Record the next state being transitioned to.
		if ($scope.appState.paused)
			return;

		if ($scope.appState.activeFeature === "equilibrium") {
			$scope.features.equilibrium.recordState(stateChange.to);
		}
		else if ($scope.appState.activeFeature === "hittingTimes") {
			$scope.features.hittingTimes.recordState(stateChange.to);
		}
		
	});




	// Textarea content for input of start probabilities
	$scope.startProbabilitiesText = null;


	$scope.inputStartProbabilities = function() {

		if ($scope.appState.startProbabilities) {
			$scope.startProbabilitiesText = $scope.appState.startProbabilities.join(', ');
		}

		var title = "Start state probabilities";
		var content = "Type the probability of starting in each state below<br>Example: 0.5, 0.3, 0.2";

		$scope.appState.message.show(title, content);

		// Strictly, we shouldn't be changing the document structure
		// inside a controller. Perhaps messages would be better as a
		// directive. Currently we are forced to add extra elements on
		// here and use the $compile service to make angular features
		// on those elements work, e.g. ng-model, ng-click.

		var el = d3.select("#message .additionalContent");

		// Draw textarea element
		el.append("textarea")
			.attr("rows", 1)
			.attr("cols", 50)
			.attr("ng-model", "startProbabilitiesText");

		// Apply button
		el.append("button")
			.attr("class", "btn btn-sm btn-default")
			.attr("ng-click", "verifyStartProbabilities()")
			.text("Apply");

		// Add the content to the document
		$compile(angular.element(el.node()))($scope);

	};



	$scope.verifyStartProbabilities = function() {

		// Get textarea content
		var p = $scope.startProbabilitiesText || ' ';
		p = p.replace(/\s/g, '');

		// Check for existence of text
		if (!p) {
			$scope.appState.message.error = "No input";
			return;
		}

		// Split by commas, map to numeric type
		var parts = p.split(',').map(to_number)

		var n = $scope.appState.activeStates.length;

		// Check the right number of values was entered
		if (parts.length !== n) {
			$scope.appState.message.error = "Please specify " + n + " values";
			return;
		}

		// Check values entered were numeric
		if (_.any(parts, _.isNaN)) {
			$scope.appState.message.error = "Invalid input";
			return;
		}

		// Sum the values
		var s = d3.sum(parts);

		// Check the values sum to 1 (or close enough)
		if (Math.abs(s - 1) > 1e-10) {
			$scope.appState.message.error = "Values do not sum to 1";
			return;
		}

		// Input is valid!

		$scope.appState.message.error = null;
		$scope.appState.message.close();
		$scope.appState.startProbabilities = angular.copy(parts);
		$scope.appState.startProbabilityLabels = angular.copy(p.split(','));

	};


	/* When the option is toggled, check if this is the first time it is
	** being enabled. If so, display the input box immediately so that the
	** user does not need to click the edit button.
	*/

	$scope.$watch('appState.useStartProbabilities', function (useThem) {
		if (useThem && $scope.appState.startProbabilities === null)
			$scope.inputStartProbabilities();
	});

	$scope.$watch('appState.message.visible', function (vis) {
		if (!vis && !$scope.startProbabilitiesText
			&& $scope.appState.message.title === 'Start state probabilities')
			$scope.appState.useStartProbabilities = false;
	});





	// Hitting times end states

	$scope.printEndStates = function() {

		if (!$scope.appState.activeStates)
			return '';

		var s = $scope.features.hittingTimes.endStates.map(function(i) {
			return $scope.appState.activeStates[i].label;
		});

		return '[ ' + s.join(', ') + ' ]';

	};



	$scope.endStateSelectorVisible = false;

	$scope.toggleEndStateSelector = function() {

		if (!$scope.features.hittingTimes.finished) return;

		$scope.endStateSelectorVisible = !$scope.endStateSelectorVisible;

		var es;

		if (!$scope.endStateSelectorVisible) {

			es = [];

			$scope.features.hittingTimes.isEndState.forEach(function(isEnd, i) {

				if (isEnd) es.push(i);

			});

			$scope.features.hittingTimes.endStates = es;

		}

	};



}]);
