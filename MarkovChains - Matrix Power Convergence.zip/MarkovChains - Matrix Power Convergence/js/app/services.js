/* Store settings here and include this service where needed
** using depency injection.
*/

markovApp.factory("settings", function() {

	return {

		matrix: {

			nodesMin: 2,
			nodesMax: 8,
			nodesDefault: 3,

			// use undefined for random matrix
			initial: undefined
			//[["0.5","0.5","0","0","0"],["0","0.5","0.5","0","0"],["0.4","0","0.4","0.2","0"],["0","0","0","0.5","0.5"],["0","0","0","0.5","0.5"]]

		},

		diagram: {

			// Provide 10 colours, so maxNodes can be increased to 10 if required
			colours: ["#ED1F1F", "#2154ED", "#679C0D", "#C1B310",
			          "#A18474", "#D96512", "#AD11D4", "#0F9ABD",
			          "#007926", "#555555"]

		},

		features: {

			equilibrium: {

				speedMin: 1,
				speedMax: 10,
				speedDefault: 2,
				
				stepsMin: 50,
				stepsMax: 5000,
				stepsResolution: 50,
				stepsDefault: 100

			},

			hittingTimes: {

				speedMin: 1,
				speedMax: 10,
				speedDefault: 5,
				
				simsMin: 50,
				simsMax: 5000,
				simsResolution: 50,
				simsDefault: 100

			},

			entrapmentStates: {

			}

		}
		          
	};

});
