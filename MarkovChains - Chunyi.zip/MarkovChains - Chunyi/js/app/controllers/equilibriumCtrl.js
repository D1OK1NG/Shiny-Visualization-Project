markovApp.controller("equilibriumCtrl", ['$scope', function($scope) {


	function get_equilibrium_distribution(transitionMatrix, dp) {

		var matrix = Matrix.create(transitionMatrix),
		    identity = Matrix.I(transitionMatrix.length),
		    matrixSubIdentity = matrix.subtract(identity);

		var i, newM = [],
		    size = matrix.rows();

		for (i = 1; i < size; i++)
			newM.push(matrixSubIdentity.col(i).elements);

		var ones = d3.range(size).map(function(x) { return 1; }),
		    onesVector = Vector.create(ones);

		newM.push(onesVector.elements);

		var invMatrix = Matrix.create(newM).inverse();

		if (!invMatrix)
			return null;

		var rightHandSide = d3.range(size).map(function(x) { return 0; });
		rightHandSide[rightHandSide.length - 1] = 1;

		var rhsVector = Vector.create(rightHandSide);

		var equilibrium = invMatrix.multiply(rhsVector).elements;

		return equilibrium.map(function(prob) {
			return d3.round(prob, _.isUndefined(dp) ? 4 : dp);
		});

	}


	// Watch for changes in the active transition matrix.
	// Update the calculated equilibrium distribution in response.
	$scope.$watch(function() {
		return JSON.stringify($scope.appState.activeTransitionMatrix);
	},
	function() {
		if ($scope.appState.activeTransitionMatrix)
			$scope.features.equilibrium.equilibrium =
				get_equilibrium_distribution($scope.appState.activeTransitionMatrix);
	});



	/* Watch for changes in the results array, and when a change is detected
	** we update the counts and proportions for each state.
	*/

	$scope.$watch(function() {

		return JSON.stringify($scope.features.equilibrium.DATA);

	}, function() {

		// Get state names, e.g. ["A", "B", "C"]
		var stateNames = _.pluck($scope.appState.activeStates, "label");

		// Calculate the total times each state has been visited
		var totals = $scope.appState.activeStates.map(function(state) {

			var filteredResults = _.filter($scope.features.equilibrium.DATA, function(s) {
				return s === state.label;
			});

			return filteredResults.length;

		});

		// Calculate proportions for each state
		var proportions = (_.max(totals) > 0
			? totals.map(function(x) { return (x / d3.sum(totals)).toFixed(4); })
			: totals.map(function(x) { return "-"; }));

		// Assign the counts and proportions results to the controller scope
		// (will be used in directives and also view for this controller).
		$scope.counts = _.object(stateNames, totals);
		$scope.proportions = _.object(stateNames, proportions);

	});

}]);
