
markovApp.controller("entrapmentCtrl", ['$scope', function($scope) {

	/* We don't need to store anything here in the $scope.features
	** object of the main controller. Nothing in here is needed
	** outside of the scope of this specific controller, so we can
	** keep all of the functionality here.
	*/

	$scope.entrapmentInputsMatrix = null;
	$scope.entrapmentInputsNone = null;
	$scope.entrapmentMessage = "";
	$scope.formCorrect = false;

	var failedAttempts = 0,
	    showAnswerThreshold = 1;


	// When a new transition matrix is applied, we reset the
	// entrapments selection form.
	$scope.$watch(function() {
		return JSON.stringify($scope.appState.activeTransitionMatrix);
	}, function() {

		if (!$scope.appState.activeTransitionMatrix)
			return;

		reset_entrapment_form();

	});


	// Make sure that within rows of inputs, checking/selecting the None
	// checkbox unchecks all the other checkboxes within the same row.
	$scope.$watch(function() {
		return JSON.stringify($scope.entrapmentInputsNone);
	}, function() {

		if (!$scope.entrapmentInputsNone || !$scope.entrapmentInputsMatrix)
			return;

		// No need to do anything if none of the state checkboxes are checked.
		if (!_.any(_.flatten($scope.entrapmentInputsMatrix)))
			return;

		$scope.entrapmentInputsMatrix.forEach(function(row, i) {

			if (_.any(row) && $scope.entrapmentInputsNone[i])
				$scope.entrapmentInputsMatrix[i] = repeat(false, $scope.appState.activeStates.length);

		});
		
	});


	// Make sure that within rows of inputs, checking/selecting any
	// state checkboxes causes the None checkbox in the same row to become
	// unchecked.
	$scope.$watch(function() {
		return JSON.stringify($scope.entrapmentInputsMatrix);
	}, function() {

		if (!$scope.entrapmentInputsNone || !$scope.entrapmentInputsMatrix)
			return;

		// No need to do anything if none of the 'None' checkboxes are checked.
		if (!_.any($scope.entrapmentInputsNone))
			return;

		$scope.entrapmentInputsMatrix.forEach(function(row, i) {

			if (_.any(row) && $scope.entrapmentInputsNone[i])
				$scope.entrapmentInputsNone[i] = false;

		});
		
	});


	function set_message(text) {
		$scope.entrapmentMessage = text;
	}

	
	function reset_entrapment_form() {

		var a = [],
		    states = $scope.appState.activeStates;

		states.forEach(function(state, i) {

			a.push([]);

			states.forEach(function(state2, j) {
				a[i].push(false);
			});

		});

		$scope.formCorrect = false;
		set_message("");
		$scope.entrapmentInputsMatrix = a;
		$scope.entrapmentInputsNone = repeat(false, states.length);
		failedAttempts = 0;

	}


	$scope.checkEntrapmentForm = function() {

		// reset message
		set_message("");

		var i, message,
			noneChecked,
			rowsNotSelected = [],
			numNotSelected,
		    n = $scope.appState.activeStates.length;

		// Loop through the rows. Check for any rows where no options
		// have been selected.
		for (i = 0; i < n; i++) {

			noneChecked = $scope.entrapmentInputsNone[i];

			if (!noneChecked && !_.any($scope.entrapmentInputsMatrix[i])) {
				rowsNotSelected.push($scope.appState.activeStates[i].label);
			}

		}

		numNotSelected = rowsNotSelected.length;

		if (numNotSelected > 0) {

			message = (numNotSelected > 1 ? "Rows" : "Row")
				+ " " + item_list_text(rowsNotSelected) + " "
				+ (numNotSelected > 1 ? "have" : "has")
				+ " no options selected.";

		}

		// If a message was set in the above for loop, then there are
		// invalid rows (no options selected). Set error message and exit
		// function. Do not count this as a failed answer, because it is
		// not a valid answer that needs to be checked against the solution.
		if (message) {
			$scope.formCorrect = false;
			set_message(message);
			return;
		}

		// We can now procees to verify whether or not the selected options
		// match up with the entrapments matrix, i.e. the user identified
		// the entrapment states correctly or not.

		var rowsWrong = [],
		    numRowsWrong,
			noTrapsAnywhere,
		    noTrapsThisRow,
		    missedTraps,
		    falsePositives,
		    trapsIdentified;

		// Loops through the rows of options
		for (i = 0; i < n; i++) {

			// Is the 'None' checkbox selected?
			noneChecked = $scope.entrapmentInputsNone[i];

			// Are there no entrapments in this row?
			noTrapsThisRow = _.all($scope.appState.entrapments[i]);

			// Has the user said there are no trapping states, when there are?
			missedTraps = noneChecked && !noTrapsThisRow;
			
			// Did the user identify trapping state(s) in this row, where there are none?
			falsePositives = !noneChecked && noTrapsThisRow;

			if (missedTraps || falsePositives) {
				rowsWrong.push($scope.appState.activeStates[i].label);
				continue;
			}

			// User has identified trapping state(s) in this row,
			// and there are actually trapping state(s) present.
			// Need to check they have identified them correctly.
			trapsIdentified = $scope.entrapmentInputsMatrix[i].map(function(isTrap) {
				return isTrap ? 0 : 1;
			});

			if (trapsIdentified.join("") !== $scope.appState.entrapments[i].join("")) {
				rowsWrong.push($scope.appState.activeStates[i].label);
			}

		}

		numRowsWrong = rowsWrong.length;

		if (numRowsWrong > 0) {

			message = (numRowsWrong > 1 ? "Rows" : "Row")
				+ " " + item_list_text(rowsWrong) + " "
				+ (numRowsWrong > 1 ? "are" : "is")
				+ " incorrect.";

		} else {

			noTrapsAnywhere = _.all(_.flatten($scope.appState.entrapments));

			message = (noTrapsAnywhere
				? "Well done! There are no entrapment states."
				: "Well done! You identified all entrapment states.");

		}


		$scope.formCorrect = (rowsWrong.length === 0);
		set_message(message);

		if (!$scope.formCorrect)
			failedAttempts++;

	}



	$scope.showAnswerVisible = function() {
		return failedAttempts >= showAnswerThreshold;
	};



	$scope.showAnswer = function() {

		$scope.formCorrect = true;
		set_message("Showing correct answer.");

		$scope.appState.entrapments.forEach(function(row, i) {

			if (_.all(row)) {

				$scope.entrapmentInputsNone[i] = true;

			} else {

				$scope.entrapmentInputsNone[i] = false;

				row.forEach(function(col, j) {

					$scope.entrapmentInputsMatrix[i][j] = (col === 0);

				});

			}

		});

	};

}]);