markovApp.directive("columnChart", ['$rootScope', 'settings',

	function($rootScope, settings) {


	function link(scope, el, attr) {

		var d3El = d3.select(el[0]),
		    svgEl = d3El.append("svg"),
		    width = 400,
		    height = 200,
		    xPadding = 20,
		    yPadding = 20;

		svgEl.attr("width", width)
			.attr("height", height)
			.attr("id", "columnChart");

		var labelsG = svgEl.append("g")
			.attr("class", "labels");

		var xScale = d3.scale.ordinal()
			.rangeRoundBands([xPadding, width - xPadding], 0.3);

		var yScale = d3.scale.linear()
			.range([height - yPadding, yPadding])
			.domain([0, 1]);

		var tickValues = d3.range(6).map(function(x) { return x/5; });

		var yAxis = d3.svg.axis()
			.scale(yScale)
			.orient("left")
			.outerTickSize(0)
			.innerTickSize(0)
			.tickValues(tickValues);

		svgEl.append("g")
			.attr("class", "axis")
			.attr("transform", "translate(" + (10 + xPadding) + ",0)")
			.call(yAxis);


		var xGridlines = svgEl.append("g")
			.attr("class", "xGridlines");

		tickValues.forEach(function(v) {
			xGridlines.append("line")
				.attr("x1", xPadding + 10)
				.attr("x2", width - xPadding - 10)
				.attr("y1", yScale(v))
				.attr("y2", yScale(v));
		});

		var barsG = svgEl.append("g")
			.attr("class", "bars")
			.attr("transform", "scale(1, -1)");

		var equilibriumG = svgEl.append("g")
			.attr("class", "equilibriumPoints");

		var bars, counts = {};


		function chart_init() {

			if (!_.isArray(scope.states)
				|| _.isUndefined(scope.equilibrium))
				return;

			counts = {};

			scope.states.forEach(function(s) {
				counts[s.label] = 0;
			});

			xScale.domain(_.pluck(scope.states, "label"));

			svgEl.select(".bars").selectAll("rect").remove();
			svgEl.select(".labels").selectAll("text").remove();
			svgEl.select(".equilibriumPoints").selectAll("circle").remove();

			labelsG.selectAll("text")
				.data(scope.states)
				.enter()
				.append("text")
					.attr("x", function(d) {
						return xScale(d.label) + xScale.rangeBand()/2;
					})
					.attr("y", height - 2)
					.attr("text-anchor", "middle")
					.text(function(d) {
						return d.label;
					});

			bars = barsG.selectAll("rect")
				.data(scope.states);

			bars.enter().append("rect")
				.attr("y", - (height - yPadding))
				.attr("x", function(d) {
					return xScale(d.label);
				})
				.attr("height", 0)
				.attr("width", xScale.rangeBand())
				.style("fill", function(d) {
					return scope.colours[d.index];
				})
				.style("stroke", function(d) {
					return d3.rgb(scope.colours[d.index]).darker(1);
				});


			if (scope.equilibrium) {

				var equilibriumPoints = equilibriumG.selectAll("circle");
				var equilibriumData = [];

				scope.states.forEach(function(s, i) {
					var o = angular.copy(s);
					o.equilibrium = scope.equilibrium[i];
					equilibriumData.push(o);
				});

				var pts = equilibriumPoints.data(equilibriumData, function(d) {
					return d.index;
				});

				pts.enter()
					.append("circle")
						.attr("cx", function(d) {
							return xScale(d.label) + xScale.rangeBand()/2;
						})
						.attr("cy", function(d) {
							return yScale(d.equilibrium);
						})
						.attr("r", 3);

				scope.$watch('features.equilibrium.showEquilibrium', function(show) {
					pts.style('opacity', show ? 1 : 0);
				});

			}

		}


		// Throttle the graph update function because data can be generated
		// rapidly, especially when animation is disabled and we are running
		// the simulation at maximum speed.
		function update() {

			// Cap animations between 200 and 500 milliseconds length.
			var t = Math.max(200, scope.features.all.getAnimationDuration())

			bars.transition()
				.ease("cubic-out")
				.duration(Math.min(500, t))
				.attr("height", function(d) {
					var total = d3.sum(_.values(counts))
					return (total > 0
						? yScale(0) - yScale(counts[d.label] / total)
						: 0);
				});

		}

		var update_throttled = _.throttle(update, 200);




		// Watch for changes to the data array. Update the counts.
		// Then call the throttled update function.

		scope.$watch(function() {

			return JSON.stringify(scope.data);

		}, function(newVal, oldVal) {

			// Quit if data is not an array
			if (!_.isArray(scope.data)) {
				return;
			}

			// parse oldData json
			var oldData = JSON.parse(oldVal)

			// If oldData is an array, and the current data array is shorter,
			// then a new simulation must have begun. Reset the chart.
			if (_.isArray(oldData) && scope.data.length < oldData.length)
				reset();

			// Add most recent data point to counts
			counts[_.last(scope.data)] ++;

			// If data exists, update the chart
			if (scope.data.length > 0)
				update_throttled();

		});


		// Watch for matrixApply and reset events. Call the reset function
		// when these events occur.
		scope.$on("matrixApply", reset);
		scope.$on("reset", reset);

		// Reset function. Call to reset the graph to it's starting state.
		function reset() {
			chart_init();
		}


		// Sometimes after matrixApply, equilibrium still hasn't been
		// calculated. So we watch for changes to that as well, and reset
		// the chart when a change occurrs.

		scope.$watch(function() { return JSON.stringify(scope.equilibrium); },
			function() {
				if (scope.equilibrium)
					reset();
			})

	}


	return {
		restrict: 'A',
		link: link,
		scope: {
			data: '=',
			colours: '=',
			states: '=',
			time: '=',
			equilibrium: '=',
			features: '='
		}
	};

}]);
