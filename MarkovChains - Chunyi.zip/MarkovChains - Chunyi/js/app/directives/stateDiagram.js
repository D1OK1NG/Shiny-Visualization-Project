markovApp.directive('stateDiagram', ['$sce', '$timeout', 'settings',
	function($sce, $timeout, settings) {

	function link(scope, el, attr) {

		var nodeRadius = 20,
		    center = [0.45, 0.5],
		    d3El = d3.select(el[0]),
		    size = get_element_size(el[0]),
		    width = size.width,
		    height = size.height,
		    svgEl = d3El.append("svg"),
		    svg = svgEl.append("g");

		svgEl.attr({width: width, height: height});

		var zoom = d3.behavior.zoom()
			.scaleExtent([0.5, 2])
			.on("zoom", function() {
				svg.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
			});

		svgEl.call(zoom);

		// Colours for the nodes
		var colours = settings.diagram.colours;

		// Set up (empty) collection for the diagram links
		var links = svg.append('g')
			.attr('class', 'links')
			.selectAll('paths');

		// Set up (empty) collection for diagram nodes
		var nodes = svg.append('g')
			.attr('class', 'nodes')
			.selectAll('g');

		// Set up markers collection for the diagram links
		var markers = svg.append('defs')
			.selectAll('.linkMarker');

		// Object to store the link elements
		var linkElements = {};

		// Create a force layout
		var force = d3.layout.force()
		    .size([width, height])
			.linkDistance(function(d) {
				return width / scope.appState.activeStates.length + (1 - d.value) * width / 6;
			})
			.linkStrength(1)
			.charge(function(d) {
				return -12000 + scope.appState.activeStates.length * 1000;
			});

		var drag = force.drag()
			.on("dragstart", function dragStarted() {
				// Stop the drag event from propagating up to the svg container.
				// If we don't do this, dragging on nodes is the same as dragging
				// the whole SVG image.
				d3.event.sourceEvent.stopPropagation();
			});

		// Create the element for the current state. This is the circle
		// that moves along between states.
		var currentStateG = svg.append('g')
			.attr('class', 'currentState')
			.attr('transform', 'translate(' + [width / 2, height / 2] + ')')
			.style('opacity', 0);

		currentStateG.append('circle')
			.attr('id', 'currentStateCircle')
			.attr('r', nodeRadius / 2);


		// Local function for highlighting the node that corresponds to the
		// currentState variable.

		function highlightCurrentNode() {
			nodes.each(function(d, i) {
				d3.select(this)
					.classed('currentNode', i === currentState);
			});
		}


		var tap = new Audio('tap.mp3');
		//tap.volume = scope.appState.features.hittingTimes.volume;

		scope.$watch('features.hittingTimes.volume', function(v) {
			if (!_.isUndefined(v))
    			tap.volume = +v;
    	});

		function expandActiveNode() {

			var s = scope.appState.selectedTransition,
			    animation = scope.features[scope.appState.activeFeature].animation;

			var node = svg.select(".currentNode").select("circle");

			if (animation) {
				tap.currentTime = 0;
				tap.play();
			}
	
			node.attr("r", nodeRadius * 2.5)
				.transition()
				.duration(200)
				.attr("r", nodeRadius);

		}

		var currentState;

		var setCurrentState = function(state) {
			currentState = state;
			scope.features[scope.appState.activeFeature].currentState = state;
			highlightCurrentNode();
		}


    	// Local function for highlighting the link that corresponds to
    	// the currently active transition.

		var selectActiveTransition = function() {

			var s = scope.appState.selectedTransition,
			    animation = scope.features[scope.appState.activeFeature].animation;

			// Only proceed if transition is set and animation is enabled.
			if (animation && s) {

				// Loop through the link elements and add the active class
				// to the currently active link.
				links.each(function(d, i) {

					var active = (scope.appState.selectedTransition[0] === d.source.index
						&& scope.appState.selectedTransition[1] === d.target.index);

					d3.select(linkElements[d.source.index + '-' + d.target.index])
						.classed('active', active);

				});
			}

		};


		/* Local function for positioning the current state element. This is
		** the SVG element that travels along the links between nodes, visible
		** when animation is enabled. This function means we can avoid sudden
		** jarring jumps of the current state element in certain circumstances.
		** The position is usually set whilst opacity is zero (element hidden).
		*/
		var positionCurrentStateElement = function(anchorToState) {

			if (_.isUndefined(anchorToState) || anchorToState < 0)
				return;

			nodes.each(function(d, i) {
				if (scope.appState.activeStates[anchorToState].label === d.label) {
					currentStateG.attr("transform", d3.select(this).attr("transform"));
				}
			});

		};


		var fixNodesTimeout = null; // variable to store timeout id for node-fixation


		// Watch the generatedAt property. This is updated every time the matrix
		// apply button is clicked, even when no new matrix has been created.

    	scope.$watch('appState.generatedAt', function(t) {
    		if (t)
    			update();
    	});


    	// Watch for the user turning changing the animation setting. When it is
    	// disabled, make sure the active link is made inactive.

    	scope.$watch(function() {

    		return scope.features[scope.appState.activeFeature].animation;

    	}, function(enabled) {

    		if (!enabled) {
    			d3.select(".link.active").classed('active', false);
    		} else {
    			selectActiveTransition();
    		}

    	});


		/* Watch for changes in the running property of any relevant features.
		** When changed to true, reset stepsCounter to 0 (abandons the individual
		** hitting time simulation that was active and starts fresh at the start state).
		** Would be good to change this behaviour in the future so that stepsCounter
		** and currentState are stored variables, such that we don't have to abandon
		** any individual hitting times simulations.
		**
		** NOTE: This must go above the watch statement for appState.paused.
		** Otherwise loop gets called once and then stepCounter gets reset to zero,
		** which is not what we want to happen.
		*/
		scope.$watch('features.hittingTimes.running', function(isRunning) {
			if (isRunning)
				positionCurrentStateElement(scope.features.hittingTimes.currentState);
		});
		scope.$watch('features.equilibrium.running', function(isRunning) {
			if (isRunning)
				positionCurrentStateElement(scope.features.equilibrium.currentState);
		});


		/* Watch for pause and unpause events. When a pause event occurs, make the
		** current state element transparent (zero opacity). When an unpause event
		** event occurs, make the current state element fully visible, and resume
		** the simulation by calling the loop function.
		*/
		scope.$watch('appState.paused', function() {
			currentStateG.select("circle").style('opacity', scope.appState.paused ? 0 : 1);
			if (!scope.appState.paused)
				loop();
		});



		/* Watch for changeHighlightedState events. These occur when:
		** (1) initialState is changed while equilibrium feature is active,
		** (2) fromState is changed while hittingTimes feature is active,
		** (3) The active feature is changed, in which case we use the
		**     currentState property of the relevant feature.
		*/
		scope.$on("changeHighlightedState", function(evt, s) {
			setCurrentState(s);
			positionCurrentStateElement(currentState);
		})



		/* Watch for changes in the active feature. Set the current state accordingly.
		** To emulate having no current state, set currentState to a negative value.
		** Also highlight the node for the new current state and reposition the current
		** state element accordingly.
		*/
		scope.$watch('appState.activeFeature', function(f) {

			var s;

			if (f === "equilibrium") {
				s = scope.features.equilibrium.currentState;
			} else if (f === "hittingTimes") {
				s = scope.features.hittingTimes.currentState;
			} else {
				s = -1;
			}

			setCurrentState(s);
			selectActiveTransition();
			positionCurrentStateElement(currentState);

		});


		// Local function for resetting various variables.
		function reset() {
			stepsCounter = 0;
			var s = (scope.appState.activeFeature === "equilibrium"
				? scope.features.equilibrium.initialState
				: scope.features.hittingTimes.fromState);
			setCurrentState(s);
		}
		
		// When a matrixApply event occurs, call the reset function.
		scope.$on("matrixApply", reset);

		// When a reset event occurs, also call the reset function.
		scope.$on("reset", function() {
			reset();
			// Deselect active transition
			selectActiveTransition();
		});


		// Local function for updating the transition diagram. Called whenever a
		// transition matrix is applied.

		function update() {

			// Do nothing if there is no active transition matrix defined
			if (!scope.appState.activeTransitionMatrix)
				return;

			// Get the links data for the D3 force layout
			var linksData = [];

			scope.appState.activeTransitionMatrix.forEach(function(transitions, fromState) {

				transitions.forEach(function(prob, toState) {

					if (prob === 0)
						return;

					linksData.push({
						source: scope.appState.activeStates[fromState],
						target: scope.appState.activeStates[toState],
						value: prob
					});

				});

			});

			// Update the nodes with the new data (active states)
			nodes = nodes.data(scope.appState.activeStates);

			// For the enter selection, insert new nodes
			var enter = nodes.enter().append('g')
				.attr('class', 'node')
				.style('fill', function(d) {
					return colours[d.index];
				})
				.call(drag);

			// Append circle for new nodes
			enter.append('circle')
				.attr('r', nodeRadius);

			// Append text labels for new nodes
			enter.append('text')
				.attr('transform', 'translate(0,5)')
				.text(function(d) { return d.label; });

			// Remove any nodes in the exit selection
			nodes.exit().remove();

			// Highlight the node corresponding to the current state
			highlightCurrentNode();

			// Key function for binding data to the link elements
			var linkKey = function(d) {
				return (d.source.index + '-' + d.target.index);
			};

			// Update the link elements with new link data
			links = links.data(linksData, linkKey);

			// Append new elements for links in the enter selection
			links.enter().append('path')
				.attr('marker-end', function(d) {
					return 'url(#linkMarker-' + d.source.index + '-' + d.target.index + ')';
				})
				.classed('link', true)
				.style('stroke', function(d){
					return colours[d.target.index];
				});

			// Remove links in the exit selection
			links.exit().remove();

			scope.appState.selectedTransition = [-1, -1];
			selectActiveTransition();


			links.style('stroke-width', function(d) {
				return 3 + d.value * 7;
				// Previous value was: Math.sqrt(Math.max(100 * d.value, 2))
			});

			// Update the cache of link elements (cache them for faster access)
			links.each(function(d, i) {
				linkElements[d.source.index + '-' + d.target.index] = this;
			});

			// Update the markers with the new link data
			markers = markers.data(linksData, linkKey);

			// Append new markers for markers the enter selection
			markers.enter().append('marker')
				.attr('id', function(d) {
					return 'linkMarker-' + d.source.index + '-' + d.target.index
				})
				.attr({
					'class': "linkMarker",
					'orient': "auto",
					'markerWidth': 2,
					'markerHeight': 4,
					'refX': 0,
					'refY': 2
				})
				.append('path')
					.attr('d', 'M0,0 V4 L2,2 Z')
					.style('fill', function(d) {
						return colours[d.target.index];
					});

			// Remove markers in the exit selection
			markers.exit().remove();

			// Update the force layout with the new nodes and links
			force.nodes(scope.appState.activeStates)
				.links(linksData);

			// Start the force layout algorithm, then after 2 seconds we call
			// force.stop(), to keep the layout from moving. This gives the
			// layout algorithm time to optimise the layout of the svg elements
			// before fixing them in place. We need to store the timeout in a
			// variable, in case the update function is called again before the
			// timeout action has executed. In that scenario, we want to forget
			// about the previous timeout action and set a new one.

			// Clear timeout if already set
			if (fixNodesTimeout && !scope.appState.startedSimulation)
				$timeout.cancel(fixNodesTimeout);

			// Start the force layout simulation
			force.start();

			// Schedule the force layout algorithm to stop after 2 seconds.
			// Fix the nodes in place so that they can be dragged individually.
			// Without explicitly fixing each node, dragging on a node causes
			// the whole force layout to be dragged along with that node.
			fixNodesTimeout = $timeout(function() {
				force.stop();
				nodes.each(function(n) {
					n.fixed = true;
				});
				fixNodesTimeout = null;
			}, 2000);


		}	// end update function


		// This function runs for every iteration of the force layout algorithm,
		// from when force.start() is called until it stops.

		force.on('tick', function() {
 
			// The code for the d attr of links is largely unchanged from the original
			// code at http://setosa.io/blog/2014/07/26/markov-chains/index.html

			links.attr('d', function(d) {

				var r = nodeRadius,
				    p1 = make_vector(d.source.x, d.source.y),
				    p2 = make_vector(d.target.x, d.target.y),
				    dir = p2.sub(p1),
				    u = dir.unit();

				if (d.source !== d.target) {

					var right = dir.rot(Math.PI /2).unit().scale(50),
					    m = p1.add(u.scale(dir.len() / 2)).add(right);
					u = p2.sub(m);
					var l = u.len();
					u = u.unit();
					p2 = m.add(u.scale(l - r * (1.33 + d.value)));
					u = p1.sub(m);
					l = u.len();
					u = u.unit();
					p1 = m.add(u.scale(l - r * 1.25));
					return 'M' + p1.array().join(",") +
						'S' + m.array().join(",") + ' '
						+ p2.array().join(",");

				} else {

					var s = 50, rot = Math.PI / 8;
					p1 = p1.add(make_vector(1, -1).unit().scale(r * 1.5 - 10));
					p2 = p2.add(make_vector(1, 1).unit().scale(r * 1.5));
					var c1 = p1.add(make_vector(1, 0).rot(-rot).unit().scale(s)),
					    c2 = p2.add(make_vector(1, 0).rot(rot).unit().scale(s - 10));
					return 'M' + p1.array().join(",")
						+ ' C' + c1.array().join(",") + ' '
						+ c2.array().join(",") + ' '
						+ p2.array().join(",");

				}

			});

			nodes.attr('transform', function(d) {
				return 'translate(' + [d.x, d.y] + ')';
			});

			
			// IE fix (there is still a problem in IE 11)
			links.each(function() {
				this.parentNode.insertBefore(this, this);
			});
			

		});	// end force.on(tick)

		// variable to count number of steps in current simulation
		// Only for hitting times feature.
		var stepsCounter = 0;
		
		function loop() {

			if (scope.appState.paused) {
				currentStateG.style("opacity", 0);
				return;
			}

			// Only gets called on the first loop function call
			// (gets called again when reset event occurs and looping restarts)
			// Need this here to make sure currentStateG position matches the position
			// of the start node in circumstances where the user may drag the nodes
			// around before running the simulation.
			if (scope.appState.activeFeature === "hittingTimes" && stepsCounter === 0) {

				// If we are running a hitting times simulation, then we are just
				// starting a new simulation. Reset the currentState variable to match
				// the fromState that the user has selected.
				setCurrentState(scope.features.hittingTimes.fromState);

			}

			// Info about which state we are currently in
			var cur = scope.appState.activeStates[currentState];

			var endLoop = false,
			    reachedToState = false;

			// Is animation turned on?
			var _animation = scope.features[scope.appState.activeFeature].animation;



			// Equilibrium only functionality
			if (scope.appState.activeFeature === "equilibrium") {

				// If we have acquired the specified amount of data, reset the step counter
				// and end calls to the loop function.
				if (scope.features.equilibrium.DATA.length >= scope.features.equilibrium.numSteps) {
					stepsCounter = 0;
					endLoop = true;
				}

			} // end if (active feature is equilibrium)

			// Hitting times only functionality
			if (scope.appState.activeFeature === "hittingTimes" && stepsCounter > 0) {

				scope.features.hittingTimes.currentHitTime = $sce.trustAsHtml("" + stepsCounter);

				// If we have reached the destination state, record how many steps
				// it took and set reachedToState to true.
				if (scope.features.hittingTimes.endStates.indexOf(cur.index) > -1) {

					// Reset current hit time to zero
					if (_animation) {
						$timeout((function(_steps) {
							return function() {
								scope.features.hittingTimes.previousHitTime = $sce.trustAsHtml("" + _steps);
								scope.features.hittingTimes.currentHitTime = $sce.trustAsHtml("0");
							}
							})(stepsCounter)
						, scope.features.all.getAnimationDuration() / 3);
					} else {
						scope.features.hittingTimes.previousHitTime = scope.features.hittingTimes.currentHitTime;
					}

					scope.features.hittingTimes.times.push(stepsCounter);
					scope.features.hittingTimes.finiteTimes.push(stepsCounter);
					reachedToState = true;
					expandActiveNode();

				}

				// If we have cannot reach the destination states, record null.
				var canReachDest = false;
				var endIndex;
				var i, n = scope.features.hittingTimes.endStates.length;
				for (i = 0; i < n; i++) {
					endIndex = scope.features.hittingTimes.endStates[i];
					canReachDest = (scope.appState.entrapments[cur.index][endIndex] !== 0);
					if (canReachDest)
						break;
				}


				// Set reachedToState to true, so the next hitting time simulation can start.
				if (!canReachDest) {
					scope.features.hittingTimes.previousHitTime = scope.features.hittingTimes.currentHitTime;
					scope.features.hittingTimes.currentHitTime = $sce.trustAsHtml("&infin;");
					scope.features.hittingTimes.times.push(null);
					reachedToState = true;
				}

				if (reachedToState) {
					// Reset step counter to zero
					stepsCounter = 0;
					// Reset current state to fromState
					setCurrentState(scope.features.hittingTimes.fromState);
					// And then update the cur variable.
					cur = scope.appState.activeStates[currentState];
					// Set currentStateG element position to fromState
					positionCurrentStateElement(currentState);
				}

				// If we have performed the specified number of hitting time simulations,
				// end calls to the loop function.
				if (scope.features.hittingTimes.times.length >= scope.features.hittingTimes.numSims)
					endLoop = true;

			} // end if (active feature is hittingTimes)

			if (endLoop) {
				// fire an event to signal that the overall simulation is done, and return.
				scope.$emit("finishedSimulation");
				// Set current state back to initial.
				setCurrentState(scope.appState.activeFeature === "equilibrium"
					? scope.features.equilibrium.initialState
					: scope.features.hittingTimes.fromState);
				scope.appState.selectedTransition = [-1, -1];
				return;
			}


			// Probabilities of transitioning to each state from the current state
			var nextStates = scope.appState.activeTransitionMatrix[currentState],
			    nextState = -1,
			    total = 0,
			    j, maxj = nextStates.length,
			    rand = Math.random();

			// Determine the next state
			for (j = 0; j < maxj; j++) {
				total += nextStates[j];
				if (rand < total) {
					nextState = j;
					break;
				}
			}

			// The next state
			var next = scope.appState.activeStates[nextState]
			// The link element we will move along to reach the next state
			var activeLink = linkElements[cur.index + '-' + next.index];

			// Emit a stateChange event. Without doing this asynchronously,
			// things don't update properly, e.g. the equilibrium distribution
			// column chart.
			$timeout(function() {
				scope.$emit('stateChange', {from: cur, to: next});
			}, 0);

			// Increment step counter
			stepsCounter++;

			// Update the selectedTransition property
			scope.appState.selectedTransition = [cur.index, next.index];
			// Highlight the current transition link element
			selectActiveTransition();

			// Update current state
			setCurrentState(nextState);

			if (_animation) {

				// If animation is turned on, set up transitions for the current state
				// element to smoothly transition between nodes, moving along the path
				// of the connection link element.

				// Duration of the whole transition sequence
				var _duration = scope.features.all.getAnimationDuration();

				currentStateG.transition()
					.duration(_duration * 0.25)
					.style('opacity', 1)
					.ease('cubic-in')
					.attrTween('transform', function() {
						// See https://github.com/mbostock/d3/wiki/Math#d3_transform
						var m = d3.transform(d3.select(this).attr('transform')),
						    start = make_vector.apply(null, m.translate),
						    scale = m.scale,
						    s = d3.interpolateArray(scale, [1, 1]);
						return function(t) {
							var end = activeLink.getPointAtLength(0);
							end = make_vector(end.x, end.y);
							var p = start.add(end.sub(start).scale(t));
							return 'translate(' + p.array().join(",") + ') scale(' + s(t) + ')';
						};
					})
					.transition()
						.duration(_duration * 0.5)
						.ease('linear')
						.attrTween('transform', function() {
							var l = activeLink.getTotalLength();
							return function(t) {
								var p = activeLink.getPointAtLength(t * l);
								return 'translate(' + [p.x, p.y] + ') scale(1)';
							};
						})
						.transition()
							.duration(_duration * 0.25)
							.ease('bounce-in')
							.attrTween('transform', function() {
								var m = d3.transform(d3.select(this).attr('transform')),
								    translation = make_vector.apply(null, m.translate),
								    scale = m.scale,
								    s = d3.interpolateArray(scale, [2, 2]);
								return function(t) {
									var end = make_vector(next.x, next.y),
									    p = translation.add(end.sub(translation).scale(t));
									return 'translate(' + p.array() + ') scale(' + s(t) + ')';
								};
							})
							.each('end', function() {
								loop();
							});

			} else {
				currentStateG.style("opacity", 0);
				$timeout(loop, 0);
			}

    	}	// end loop function

	}	// end link function

	/* Directive will be restricted to being applied with an attribute. 
	** It uses an isolated scope, with required info supplied via attributes.
	** We need access to the appState object and also the features object.
	*/

	return {
		restrict: 'A',
		link: link,
		scope: {
			appState: "=",
			features: "="
		}
	};

}]);
