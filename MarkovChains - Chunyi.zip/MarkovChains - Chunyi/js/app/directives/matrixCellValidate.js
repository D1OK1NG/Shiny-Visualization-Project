markovApp.directive("matrixCellValidate", [function() {

	return {

		require: 'ngModel',

		link: function(scope, elem, attrs, ngModel) {

			ngModel.$parsers.push(function(value) {

				if (_.isUndefined(value) || (value + "").length === 0) {
					// Empty cell in not invalid
					ngModel.$setValidity('probability', true);
					return "";
				}

				var valueNum = to_number(value);
				
				var valid = (_.isNumber(valueNum)
					&& !_.isNaN(valueNum)
					&& valueNum >= 0
					&& valueNum <= 1);

				ngModel.$setValidity('probability', valid);

				return valid ? value : undefined;

			});

		}
	};

}]);
