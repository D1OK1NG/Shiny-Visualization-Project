markovApp.controller("equilibriumCtrl", ['$scope', function($scope) {


	function get_equilibrium_distribution(transitionMatrix, dp) {

		var matrix = Matrix.create(transitionMatrix),
		    identity = Matrix.I(transitionMatrix.length),
		    matrixSubIdentity = matrix.subtract(identity);

		var i, newM = [],
		    size = matrix.rows();

		for (i = 1; i < size; i++)
			newM.push(matrixSubIdentity.col(i).elements);

		var ones = d3.range(size).map(function(x) { return 1; }),
		    onesVector = Vector.create(ones);

		newM.push(onesVector.elements);

		var invMatrix = Matrix.create(newM).inverse();

		if (!invMatrix)
			return null;

		var rightHandSide = d3.range(size).map(function(x) { return 0; });
		rightHandSide[rightHandSide.length - 1] = 1;

		var rhsVector = Vector.create(rightHandSide);

		var equilibrium = invMatrix.multiply(rhsVector).elements;

		return equilibrium.map(function(prob) {
			return d3.round(prob, _.isUndefined(dp) ? 4 : dp);
		});

	}


	// Watch for changes in the active transition matrix.
	// Update the calculated equilibrium distribution in response.
	$scope.$watch(function() {
		return JSON.stringify($scope.appState.activeTransitionMatrix);
	},
	function() {
		if ($scope.appState.activeTransitionMatrix)
			$scope.features.equilibrium.equilibrium =
				get_equilibrium_distribution($scope.appState.activeTransitionMatrix);
	});



	/* Watch for changes in the results array, and when a change is detected
	** we update the counts and proportions for each state.
	*/

	$scope.$watch(function() {

		return JSON.stringify($scope.features.equilibrium.DATA);

	}, function() {

		// Get state names, e.g. ["A", "B", "C"]
		var stateNames = _.pluck($scope.appState.activeStates, "label");

		// Calculate the total times each state has been visited
		var totals = $scope.appState.activeStates.map(function(state) {

			var filteredResults = _.filter($scope.features.equilibrium.DATA, function(s) {
				return s === state.label;
			});

			return filteredResults.length;

		});

		// Calculate proportions for each state
		var proportions = (_.max(totals) > 0
			? totals.map(function(x) { return (x / d3.sum(totals)).toFixed(4); })
			: totals.map(function(x) { return "-"; }));

		// Assign the counts and proportions results to the controller scope
		// (will be used in directives and also view for this controller).
		$scope.counts = _.object(stateNames, totals);
		$scope.proportions = _.object(stateNames, proportions);

	});

	    // ---------------- Algebraic Link helpers ----------------

    // 向量(行) × 矩阵
    function vecMulMat(vec, mat) {
        var n = vec.length;
        var out = new Array(n);
        var i, j, sum;
        for (j = 0; j < n; j++) {
            sum = 0;
            for (i = 0; i < n; i++) {
                sum += vec[i] * mat[i][j];
            }
            out[j] = sum;
        }
        return out;
    }

    // 判断两次迭代是否收敛（差异足够小）
    function isConverged(a, b, tol) {
        if (tol === undefined) tol = 1e-4;
        for (var i = 0; i < a.length; i++) {
            if (Math.abs(a[i] - b[i]) >= tol) return false;
        }
        return true;
    }

    function format4(x) {
        return (x === null || x === undefined) ? "-" : x.toFixed(4);
    }

    // 在 scope 上挂一个对象存放代数链结果
    $scope.algLink = {
        initialPi: [],
        steps: [],
        convergedStep: null
    };

	    // 主入口：点击 "Show Algebraic Link" 时调用
    $scope.runAlgebraicLink = function() {

        var P = $scope.appState.activeTransitionMatrix;
        if (!P || !P.length) {
            $scope.algLink.initialPi = [];
            $scope.algLink.steps = [];
            $scope.algLink.convergedStep = null;
            return;
        }

        var n = P.length;
        var pi0 = [];
        var i;

        // 1) 尝试用当前模拟的 Proportion 作为 π(0)
        //    proportions 形如 {A: "0.1629", B: "0.1571", ...}
        var stateNames = _.pluck($scope.appState.activeStates, "label");
        var totals = stateNames.map(function(name) {
            return $scope.counts && $scope.counts[name] ? $scope.counts[name] : 0;
        });
        var totalN = d3.sum(totals);

        if (totalN > 0) {
            // 用 Count / Total 得到经验分布
            pi0 = totals.map(function(cnt) {
                return cnt / totalN;
            });
        } else if ($scope.features.equilibrium.equilibrium) {
            // 2) 如果还没有跑模拟，但有理论 equilibrium，就用它
            pi0 = $scope.features.equilibrium.equilibrium.slice();
        } else {
            // 3) 兜底：均匀分布
            for (i = 0; i < n; i++) pi0.push(1 / n);
        }

        // 初始化 Algebraic Link 状态
        $scope.algLink.initialPi = pi0.map(format4);
        $scope.algLink.steps = [];
        $scope.algLink.convergedStep = null;

        var maxSteps = 50;
        var step = 0;
        var pi = pi0.slice();
        var nextPi;

        while (step < maxSteps) {
            step++;

            nextPi = vecMulMat(pi, P);

            $scope.algLink.steps.push({
                step: step,
                pi_k: pi.map(format4),
                pi_next: nextPi.map(format4)
            });

            if (isConverged(pi, nextPi)) {
                $scope.algLink.convergedStep = step;
                break;
            }

            pi = nextPi;
        }
    };

}]);
