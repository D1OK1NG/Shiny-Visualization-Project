markovApp.controller("hittingTimeCtrl", ['$scope', '$sce', function($scope, $sce) {


	// This will store the expected hitting times for single end states
	$scope.expectedHittingTimes = null;

	// Object to store expected hitting times for groups of end states.
	// example: key 'AB' will store an array of expected hitting times from
	// each state to group [AB].
	$scope.groupHittingTimes = {};

	// Expected hitting time for currently selected from->to path.
	$scope.expected = null;




	// Watch for changes to whether or not a hitting time simulation is finished

	$scope.$watch("features.hittingTimes.finished", function(isFinished) {

		if (isFinished) {

			// If simulation just finished, remove current hit time
			$scope.features.hittingTimes.currentHitTime = $sce.trustAsHtml("-");

		} else {

			// Hitting time simulation is just starting

			var from = $scope.features.hittingTimes.fromState,
			    to = $scope.features.hittingTimes.endStates;

			// Expected hitting time to get from start state to end state(s)
			var e;

			if (to.length === 1) {

				// Only one end state, grab the value from the standard matrix of
				// hitting times.
				e = $scope.expectedHittingTimes[from][to[0]];

			} else {

				// Multiple end states. These calculations for theoretical hitting times
				// are much more complex

				var groupHitTimes;

				// Key to find the times in the groupHittingTimes store.
				var key = [].concat(to).sort(function(a,b) { return a - b; }).join('');

				if ($scope.groupHittingTimes[key]) {

					// Key was found in the store, so retrieve the values
					groupHitTimes = $scope.groupHittingTimes[key];

				} else {

					// Key not found in store, calculate the hit times
					groupHitTimes = get_hitting_times_multiple_end_states(to);

					// Save the times in the store
					$scope.groupHittingTimes[key] = [].concat(groupHitTimes);

				}

				// Grab the element from the group hit times array which corresponds to
				// the start state
				e = groupHitTimes[from];

			}

			// Set expected hitting time (or dashes if a solution does not exist)
			$scope.expected = e || '---';

		}

	});





	// Function for applying the standard hitting times formula to a given
	// transition matrix. Calculates all hit times to single end states only.
	// There are cases where this formula fails to give results (when closed
	// classes exist) but theoretical times do exist. These are determined
	// after applying this initial formula.

	function apply_hitting_times_formula (transitionMatrix, states) {

		var meanHittingTimes = [],
		    A, b,
		    n = states.length,
		    probs = transitionMatrix;

		states.forEach(function(toState, s) {

			//  m_i_s = expected hitting time from state i to state s.
			//
			//  m_i_s = |  0                              , if i == s,
			//          |  1 + sum{j!=s} (p_i_j * m_j_s)  , otherwise

			A = [];
			b = [];

			states.forEach(function(fromState, i) {

				// For given s, form the equation for each m_i_s

				var rowA = [];

				if (i === s) {

					b[i] = 0;
					rowA = repeat(0, n);
					rowA[i] = 1;

				} else {

					b[i] = 1;
					states.forEach(function(jState, j) {
						rowA[j] = (i === j
							? 1 - probs[i][j]
							: - probs[i][j]);
					});

				}

				A.push(rowA);

			});

			A = Matrix.create(A);
			b = Vector.create(b);

			var inverseA = A.inverse(),
			    times;

			if (inverseA) {

				times = inverseA.multiply(b).elements;
				times = _.map(times, function(t) { return d3.round(t, 3); });

			} else {

				times = repeat(null, n);
				times[s] = 0;

			}

			meanHittingTimes[s] = times;

		});

		// Need to transpose the matrix. Currently the (i,j) element represents
		// expected hit time from state j to i. This is counter-intuitive.
		meanHittingTimes = Matrix.create(meanHittingTimes).transpose().elements;

		return meanHittingTimes;

	};






	// Function for getting an array of hitting times to a group of end states.
	// This algorithm is quite complex, it involves splicing parts of the full
	// transition matrix into sub-matrices and modifying those sub-matrices such
	// that they are valid transition matrices and also such that the modifications
	// do not interfere with the theoretical result we are trying to calculate.
	// To get our results we apply the group hitting times  algorithm to those
	// sub-matrices.

	function get_hitting_times_multiple_end_states (endGroup) {

		// Get transition matrix
		var tm = $scope.appState.activeTransitionMatrix;

		// Get array of active states
		var states = $scope.appState.activeStates;

		// Get entrapments matrix
		var em = $scope.appState.entrapments;

		// If there are no entrapping states at all, apply the algorithm to the
		// full transition matrix
		if (_.all(_.flatten(em)))
			return apply_group_hitting_times_algorithm(endGroup, tm);

		// Set initial hitting times array to nulls
		var hitTimes = repeat(null, states.length);

		// Sort endGroup in ascending order just in case it is not already
		endGroup.sort(function(a, b) { return a - b; });


		// Loop through the states

		states.forEach(function(s, i) {

			if (hitTimes[i])
				return;

			// Remove any states from end group that cannot be reached from s
			var endGroupFinal = endGroup.filter(function(j) {
				return em[i][j] === 1;
			});

			// Size of modified endGroup array
			var endGroupFinalSize = endGroupFinal.length;

			// If we cannot get to any of the end states from state s, then no
			// theoretical hitting time exists. Return from function, leaving
			// the hitting time value as null.
			if (endGroupFinalSize === 0)
				return;

			// Now we determine which subset of states we need to slice out of
			// the full transition matrix. We need to check which subset of states
			// are intermediate from state s to the end states. We remove any states
			// that can only be reached by going through the end states, because they
			// are not relevant to the solution.

			// States we need to check
			var check = [i];

			// States we have already checked
			var alreadyChecked = [];

			// Current state being checked
			var current;

			// Current row of probabilities for the state being checked
			var tmRow;

			// Run through states we need to check
			while (check.length) {

				// Check first state in the list
				current = check.shift();

				// Add it to the array of already checked states
				alreadyChecked.push(current);

				// Probabilities to other states from current state
				tmRow = tm[current];

				// Determine which unchecked states can be reached from current state
				// and that are not in the end state group. Add any results to the array
				// of states we still need to check

				tmRow.forEach(function(prob, j) {
					if (prob > 0 && endGroupFinal.indexOf(j) === -1 && alreadyChecked.indexOf(j) === -1)
						check.push(j);
				});

			}

			// The alreadyChecked array will ultimately store the subset of states we
			// need to splice out of the full transition matrix. Make sure the end states
			// are added to the array, only if they can be reached from the original state.

			endGroupFinal.forEach(function(k) {
				if (alreadyChecked.indexOf(k) === -1 && em[i][k] === 1)
					alreadyChecked.push(k);
			});

			// Now alreadyChecked contains all states between the start state and all
			// states in the end group, inclusive.

			/*var m = alreadyChecked.length;
			var canGetTo = true;
			var j, k;

			for (j = 0; j < m; j++) {

				if (endGroup.indexOf(alreadyChecked[j]) > -1)
					continue;

				for (k = 0; k < endGroupFinalSize; k++) {

					canGetTo = em[alreadyChecked[j]][endGroupFinal[k]] === 1;

					if (!canGetTo)
						break;

				}

				if (!canGetTo)
					break;

			}

			if (!canGetTo)
				return;*/


			// Sort subset of states in ascending order
			alreadyChecked.sort(function(a, b) { return a - b; });

			// If the subset of states is equal to the end group, then the hitting time
			// will be 1. Or if the final subset consists of only a single state
			// e.g. D -> [D,E] where D is trapping results in [D] subset. Obviously this
			// also results in a hitting time of 1. In these cases, set the hitting time to
			// 1 and return.

			if (alreadyChecked.join('') === endGroupFinal.join('') || alreadyChecked.length === 1) {
				hitTimes[i] = 1;
				return;
			}
			
			// Sub transition matrix
			var subTransitionMatrix = [];

			// Store each mapping from the state currently being iterated through to
			// it's position in the sub transition matrix.
			var subMapping = {};

			// Loop through the subset of states. Store its mapping from its position
			// in the original transition matrix to its position in the sub matrix.
			// Grab the column elements from the original transition matrix into an
			// array (only the ones corresponding to the subset of states). This will
			// be a row of the new sub transition matrix.

			alreadyChecked.forEach(function(j, index) {

				// Store mapping
				subMapping[j] = index;

				// Create row of sub matrix
				var r = tm[j].filter(function(p, k) {
					return alreadyChecked.indexOf(k) > -1;
				});

				// Add row to sub matrix
				subTransitionMatrix.push(r);

			});

			// Adjust the end group probabilities, so that rows sum to 1 and the sub
			// transition matrix is a valid probability matrix. The easiest way to do
			// this is to make any end states with missing probabilities loop back onto
			// themselves with the missing probability. This does not change the expected
			// result, even if the start state is part of the end group. If the start
			// state is also part of the end group, all it's outward probability is
			// already accounted for. The only way it could be below 1 is if the start
			// state can reach other states in which it is impossible to ever reach the
			// end states. But in this situation the hitting time is null and we have
			// already exited the function. Therefore this problem never arises.

			subTransitionMatrix.forEach(function(row, index) {

				if (d3.sum(row) < 1) {
					subTransitionMatrix[index][index] += (1 - d3.sum(row));
				}

			});

			// Now we have a valid sub transition matrix with the same theoretical hitting
			// times as the original transition matrix! Only now we can apply the group
			// hitting times algorithm to calculate these results, without running into
			// the singular matrix issue.

			var ht = apply_group_hitting_times_algorithm(endGroupFinal, subTransitionMatrix);

			// Set the hitting time.
			hitTimes[i] = ht[subMapping[i]];

		});

		return hitTimes;

	}





	function apply_group_hitting_times_algorithm (group, transitionMatrix) {

		var n = transitionMatrix.length;
		var i, j;
		var x, isInGroup;

		var A = repeat([], n);

		// columns
		for (i = 0; i < n; i++) {

			isInGroup = _.contains(group, i);

			// rows
			for (j = 0; j < n; j++) {

				if (!isInGroup) {

					x = (i === j) ? (1 - transitionMatrix[j][i]) : -transitionMatrix[j][i];

				} else {

					x = (i === j) ? 1 : 0;

				}

				A[j][i] = x;

			}

		}

		var b = repeat(1, n);

		A = Matrix.create(A);
		b = Vector.create(b);

		var invA = A.inverse();
		var times;

		if (invA) {

				times = invA.multiply(b).elements;
				times = _.map(times, function(t) { return d3.round(t, 3); });

		} else {

				times = repeat(null, n);

		}

		return times;

	}





	// Helper function. Are we guarenteed to return to state i?
	// Return true if yes, false if not.

	function will_return_here(i) {

		var tm = $scope.appState.activeTransitionMatrix;
		var E = $scope.appState.entrapments;

		var willReturn = true;
		var j = 0, n = tm.length;

		while (willReturn && j < n) {

			if (E[j][i] === 0)
				willReturn = false;

			j += 1;

		}

		return willReturn;

	}





	function calculate_expected_hitting_times() {

		$scope.expected = null;
		$scope.groupHittingTimes = {};

		var tm = $scope.appState.activeTransitionMatrix;

		var meanHittingTimes = apply_hitting_times_formula(tm, $scope.appState.activeStates);


		/* The diagonals in the meanHittingTimes matrix will be zero. These values are
		** saying it takes 0 steps to reach state A given we start in state A. This is
		** not wrong, but we want  to calculate how many steps it takes to return to
		** state A given we start there. This is fairly easy to calculate, and is done
		** in the next small block of code.
		*/

		var n = meanHittingTimes.length;
		var i, j, mht = 0;

		for (i = 0; i < n; i++) {

			// If we can't return here, there is no valid return hitting time
			if (!will_return_here(i)) {
				meanHittingTimes[i][i] = null;
				continue;
			}

			// Add one step (first step away from state i)
			mht = 1;

			// Now add the expected time to get back to state i.
			for (j = 0; j < n; j++) {
				if (i !== j)
					mht += tm[i][j] * meanHittingTimes[j][i];
			}

			meanHittingTimes[i][i] = d3.round(mht, 3);

		}






		/* Using the standard apply_hitting_times_formula() function to calculate
		** expected hitting times can return some null values where a finite value
		** actually exists as the solution. This is due to singular matrices, and
		** occurs when there are some closed classes (entrapping states or groups
		** of states).

		** To combat this, after running the apply_hitting_times_formula() function,
		** we run a custom algorithm to fill in any expected hitting times that
		** should exist but were not able to be determined earlier. This algorithm
		** appears to generate the correct results after some testing.
		
		** The algorithm slices out rows and columns of the transition matrix that
		** correspond to entrapping states from which we CANNOT get to without
		** first arriving at the destination state. If we can get from state A to
		** state B before ever getting stuck in entrapping states, then we can remove
		** all entrapping states and use a sub-transition-matrix. Those states
		** do not affect the expected hitting time to get from A to B, but they cause
		** the apply_hitting_times_formula() algorithm to return null values.
		*/

		// Loop through rows of hitting times matrix
		meanHittingTimes.forEach(function(fromTimes, i) {

			// i represents the start state

			// Loop through values in each row
			fromTimes.forEach(function(tt, j) {

				// j represents the destination state

				// Grab the value directly from the matrix, because the matrix may
				// be edited within this loop.
				var toTime = meanHittingTimes[i][j];

				// If value is not null, go to next value.
				if (!_.isNull(toTime))
					return;

				var validTime = true,	// should a valid time exist?
				    checkStates = [i],	// states we will need to check
				    doneStates = [];	// states we have checked


				// We will loop through the states looking for ways to reach
				// an entrapment state before reaching the destination state.
				// If this is possible, there is no valid hitting time.

				while (checkStates.length) {

					// State to check
					var s = checkStates.shift();
					// Push this state to the doneStates array
					doneStates.push(s);

					// If this is an entrapment state, then no valid time exists.
					if ($scope.appState.entrapments[s][j] === 0) {
						validTime = false;
						break;
					}

					// get the transition probabilities for state s, the state that
					// we are currently checking
					var probs = $scope.appState.activeTransitionMatrix[s];

					// For each state we can jump to directly from the current state
					// s, add it to the checkStates array, but only if we have not
					// already checked that state earlier. Do not check destination state.
					probs.forEach(function(p, k) {

						// Do not recheck destination state
						if (k === j)
							return;

						// Only check reachable states that have yet to be checked
						if (p > 0 && !_.contains(doneStates, k))
							checkStates.push(k);

					});

				}

				// If we have determined that there is no valid hitting time, return
				// and move on to the hitting time
				if (!validTime)
					return;

				// Now we need to construct sub-transition-matrix.

				// States that we will use to form a sub-transition matrix
				var takeStates = [].concat(doneStates).concat(j);

				// Sort the list of states we will take for our sub matrix
				takeStates = _.sortBy(takeStates);

				var tm = [].concat($scope.appState.activeTransitionMatrix),
				    tm2 = [],	// this will be our new sub matrix
					substates = [];	// corresponding subset of activeStates


				// Loop through the states we will include in our new matrix
				takeStates.forEach(function(s, k) {

					// Copy this state info from appState.activeStates into
					//substates array
					substates.push($scope.appState.activeStates[s]);

					// The row we are constructing
					var row = [];

					// Take only the columns from the original transition
					// matrix that correspond to the states we are including
					// in the sub matrix
					takeStates.forEach(function(s2, k2) {
						row.push(tm[s][s2])
					});

					// Add this row to the sub matrix
					tm2.push(row);

				});

				// Due to the nature of the transition matrix in these cases,
				// all rows in the sub matrix except that corresponding to the
				// destination state will sum to 1. For the destination state
				// row, it doesn't matter what we use to make the row sum to
				// 1 - because once we reach that state we stop. So we set the
				// row to be all zeros except for the return-transition probability,
				// which we set to 1.

				var toStateProbs = repeat(0, takeStates.length);
				toStateProbs[takeStates.indexOf(j)] = 1;

				tm2[takeStates.indexOf(j)] = toStateProbs;

				// Now run this sub transition matrix through the
				// apply_hitting_times_formula() function to get the expected
				// hitting time.

				var subHittingTimes = apply_hitting_times_formula(tm2, substates);
				var newHitTime = subHittingTimes[takeStates.indexOf(i)][takeStates.indexOf(j)];

				// If old time is null, replace old time with the new time.
				if (_.isNull(meanHittingTimes[i][j]))
					meanHittingTimes[i][j] = newHitTime;

			});

		});


		// Save the matrix to the controller scope.
		$scope.expectedHittingTimes = meanHittingTimes;

	};



	// Controller behaviour for retrieving the simulation progress text
	// which is displayed while a hitting times simulation is running.
	// Returns string values such as '(70%)'.

	$scope.getCompletion = function() {

		if (!$scope.features.hittingTimes.times || $scope.features.hittingTimes.finished)
			return "";

		var n = $scope.features.hittingTimes.numSims,
		    i = $scope.features.hittingTimes.times.length;

		if (i === 0 || i === n)
			return "";

		var prct = 100 * i/n;

		return "(" + Math.floor(prct) + "%)";

	};



	// Custom options for the histogram of simulated hitting times.

	$scope.histOpts = {
		width: 480,
		margin: [10, 10, 25, 35],
		fill: "#BBBBBB",
		integerX: true,
		yAxisDP: 1,
		frequency: false
	};


	// Watch for changes to the active matrix.
	$scope.$on("matrixApply", function() {

		calculate_entrapments();
		calculate_expected_hitting_times();
		$scope.features.hittingTimes.currentHitTime = $sce.trustAsHtml("-");
		$scope.features.hittingTimes.previousHitTime = $sce.trustAsHtml("-");

	});



	// We need this function here because the entrapments matrix MUST be available
	// before the functions in this controller are executed. Putting this in the
	// entrapment controller would be nicer...

	function calculate_entrapments() {

		var tm = $scope.appState.activeTransitionMatrix,
		    em = zero_matrix(tm.length),
		    states = _.pluck($scope.appState.activeStates, "label"),
		    n = states.length;

		// Loop through each state

		states.forEach(function(s, i) {

			// Initially set states that we can't reach from current state s
			// to all state indices.
			var cantGetToStates = d3.range(n);

			// Set states whose transition probabilities are to be checked.
			var statesToCheck = [i];

			// Initially, no states have been checked.
			var checkedStates = [];

			var nextStateProbs;

			// While there are state(s) to check...
			while (statesToCheck.length) {

				// Get the state to check and remove it from the statesToCheck array.
				var currentStateBeingChecked = statesToCheck.splice(0, 1)[0];

				// Add the state being checked to the checkedStates array, so that we
				// don't recheck states unnecessarily.
				checkedStates.push(currentStateBeingChecked);

				// The transition probabilities from the current state being checked.
				nextStateProbs = tm[currentStateBeingChecked];

				var j, prob;

				// Loop through each transition probability for the next state.

				for (j = 0; j < n; j++) {

					// Probability of transitioning to the j-th state from the
					// current state being checked.
					prob = nextStateProbs[j];

					// If the probability is zero, continue straight to the next
					// iteration of the loop. If the probability represents the current
					// state going back to itself, set the entrapment matrix element
					// equal to 1.
					if (prob === 0)
						continue;

					// Positive probability of transition, so set the entrapment matrix
					// value for the i-j transition to 1, because we have determined it
					// is possible to reach the j-th state from the i-th state.
					em[i][j] = 1;

					// If the transition-to state is contained in the array of states
					// we cannot get to, remove it from that array.
					if (_.contains(cantGetToStates, j))
						cantGetToStates = _.without(cantGetToStates, j);

					// If there are still states we haven't been able to get to yet from
					// state s, and the transitions from state j have not been checked, add
					// state j to the array of states to check (but only if state j is not
					// the same as state i, which is being iterated through already).
					if (i !== j && !_.contains(checkedStates, j) && cantGetToStates.length) 
						statesToCheck.push(j);

					// If there are no states we cannot reach, break out of the loop.
					if (cantGetToStates.length === 0)
						break;

				}

			}

			// Now em, the entrapment matrix, will contain zeros in cells (a, b) only if
			// it is NOT possible to ever get from the a-th state to the b-th state.
			// That is, the two states do not 'communicate' with each other.

		});

		$scope.appState.entrapments = angular.copy(em);

	};


}]);
