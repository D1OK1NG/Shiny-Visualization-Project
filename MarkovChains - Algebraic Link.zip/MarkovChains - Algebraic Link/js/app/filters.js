markovApp.filter("pluraliseFilter", function() {

	return function(amount, singular, plural) {

		if (!plural)
			plural = singular + "s";

		if (amount === "&infin;")
			return plural;

		amount = +amount;

		if (_.isNumber(amount) && !_.isNaN(amount)) {

			return (amount === 1
				? singular
				: plural);

		}

		return "";

	};

});

markovApp.filter("statisticFilter", function() {

	return function(arr, statName, dp, fixed) {

		var result;

		if (!_.isArray(arr) || arr.length === 0)
			return null;

		switch (statName) {

			case "max":
				result = d3.max(arr);
				break; 

			case "min":
				result = d3.min(arr);
				break; 

			case "mean":
				result = d3.mean(arr);
				break; 

			default:
				result = null;

		}

		if (!_.isUndefined(dp))
			result = (fixed ? result.toFixed(dp) : d3.round(result, dp));

		return result;

	};

});