markovApp.directive('histogram', ['$rootScope', 'settings',
	function($rootScope, settings) {


	function draw (scope, el, attr) {

		var data = scope.data;

		el.empty();

		if (!_.isArray(data) || !data.length)
			return;

		var opts = scope.opts || {};

		// default opts
		if (!_.has(opts, "width"))		opts.width = 400;
		if (!_.has(opts, "height"))		opts.height = 200;
		if (!_.has(opts, "margin"))		opts.margin = [30, 30, 30, 30];	// top, right, bottom, left
		if (!_.has(opts, "fill"))		opts.fill = "#CCCCCC";
		if (!_.has(opts, "integerX"))	opts.integerX = false;
		if (!_.has(opts, "frequency"))	opts.frequency = true;

		// Actual dimensions of plot area
		var plotWidth = opts.width - opts.margin[1] - opts.margin[3],
		    plotHeight = opts.height - opts.margin[0] - opts.margin[2];

		// x scale object
		var xScale = d3.scale.linear()
			.range([0, plotWidth])
			.domain(d3.extent(data))
			.nice();

		// Total number of bins, and calculate bin boundaries
		var nBins = Math.min(_.max(data) - _.min(data), 10),
		    binBoundaries = xScale.ticks(nBins);

		// Bin the data
		var binnedData = d3.layout.histogram()
			.bins(binBoundaries)
			.frequency(opts.frequency)
			(data);

		var binSize = binnedData[0] ? binnedData[0].dx : 1;
		var barSeparation, barWidth;

		// Size of chart axis labels
		var labelSize = 12;

		// When we start off, there is only one bin. In this case, binnedData
		// is empty because the xScale domain spans a zero-length interval in
		// the real domain. To display a histogram with a single bin, we set
		// binnedData ourselves, set barWidth to the full plot width and then
		// set the xScale domain ourselves.

		if (!binnedData.length) {
			binnedData = [data];
			barWidth = plotWidth - 1;
			xScale.domain([data[0], data[0] + 1]);
		} else {
			// How much are the bars separated by?
			// If each bar is approx 30 pixels or more, use 2 pixel separation,
			// else use 1 pixel.
			barSeparation = (plotWidth / binnedData.length > 30 ? 2 : 1)
			barWidth = xScale(binnedData[0].x + binnedData[0].dx) - barSeparation;
		}

		var maxCount = d3.max(binnedData.map(function(arr) { return arr.length; })),
		    maxFreq = maxCount / data.length,
		    yMax = Math.min(1, maxFreq);

		var yScale = d3.scale.linear()
			.range([plotHeight, 0])
			.domain([0, yMax]);

		var xAxis = d3.svg.axis()
			.scale(xScale)
			.outerTickSize(1)
			.orient("bottom");

		// In some cases we only want integers to be displayed on the x axis.
		// Use the tickFormat option to achieve this.
		if (opts.integerX)
			xAxis.tickFormat(function(x) {
				return (x === Math.round(x) ? Math.round(x) : "");
			});

		var yAxis = d3.svg.axis()
			.scale(yScale)
			.ticks(plotHeight > 250 ? 10 : 5)
			.outerTickSize(1)
			.orient("left");

		var svg = d3.select(el[0]).append("svg")
			.attr("width", opts.width)
			.attr("height", opts.height)
			.append("g")
				.attr("transform", "translate(" + opts.margin[3] + "," + opts.margin[0] + ")");

		var bars = svg.selectAll(".bar")
			.data(binnedData)
			.enter()
			.append("g")
				.attr("class", "bar")
				.attr("transform", function(d) {
					return (_.isUndefined(d.x)
						? null
						: "translate(" + xScale(d.x) + "," + yScale(d.y) + ")");
				})
				.style("fill", opts.fill)
				.style("stroke", "none")
				.append("rect")
					.attr("x", barSeparation)
					.attr("y", 0)
					.attr("width", barWidth)
					.attr("height", function(d) {
						return (_.isUndefined(d.x)
							? plotHeight
							: plotHeight - yScale(d.y));
					});

		var textTranslate = (binSize === 1 ? barWidth / 2 : 0);

		svg.append("g")
			.attr("transform", "translate(0," + plotHeight + ")")
			.call(xAxis)
			.selectAll("text")
				.attr("transform",  "translate(" + textTranslate + ",0)")
				.style("font-size", labelSize + "px");

		svg.append("g")
			.call(yAxis)
			.selectAll("text")
				.style("font-size", labelSize + "px");

	}


	function link(scope, el, attr) {

		var throttledDraw = _.throttle(function() {
			draw(scope, el, attr);
		}, 200);

		scope.$watch(function() {
			return JSON.stringify(scope.data);
		}, function() {
			throttledDraw();
		});

	}


	return {
		link: link,
		restrict: "A",
		scope: {
			data: "=",
			opts: "="
		}
	};

}]);