The Discrete Probability Detective
=================================

1. Project Overview
-------------------
This project is an interactive Shiny application: "The Discrete Probability Detective".
Users follow a detective story while learning to identify and apply seven discrete probability distributions:

- Bernoulli
- Binomial
- Geometric
- Negative Binomial
- Hypergeometric
- Discrete Uniform
- Poisson

At each step of the story, the player must select the most suitable distribution.
The program provides hints, feedback, and explanations.

2. Program Flow
---------------
1) Start Screen:
   Shows the background story and game title. The player clicks a button to begin.
2) Case Investigation (steps 1–7):
   Each step presents a part of the story (sometimes with images). The player chooses among distributions.
   - Correct answer: success message, explanation, and a NEXT button.
   - Wrong answer: Hint 1, then Hint 2.
   - Still wrong: correct answer is shown with analysis.
3) Final Recap:
   The story ends with a summary and review of all seven distributions.

3. File Structure
-----------------
project/
│-- app.R         (Shiny main program)
│-- img/          (image folder for illustrations)
│     1.png
│     2.png
│     ...
│     12.png
│-- README.txt    (this document)

Note:
Images are referenced inside the app using relative paths, e.g.:
   img(src = "img/1.png", style="...")

4. Requirements
---------------
- R version 4.0 or higher
- Required package:
    install.packages("shiny")
- Optional packages for styling: shinythemes, htmltools

How to run:
Open app.R in RStudio and click "Run App".

5. Usage Instructions
---------------------
- Read the story carefully and select the distribution that matches the case.
- Wrong answers trigger hints and then corrections.
- Each distribution explanation includes:
  * Definition of the random variable
  * Parameters
  * Detective’s insight
  * Property checks

6. License
----------
This project is for educational purposes.
Free to modify and extend for teaching or personal use.
